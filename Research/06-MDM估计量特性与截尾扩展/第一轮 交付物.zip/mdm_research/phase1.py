# -*- coding: utf-8 -*-
"""phase1.py — 偏差规律系统研究: beta x n 网格, 1000次重复, MDM(0.1)/MDM(0)/MLE/LSM"""
import numpy as np, time, os
from core import mdm_fit, mle3_fit, lsm3_fit, gen_weibull3

BETAS = [1.5, 2.0, 3.0, 4.0]
NS = [5, 10, 20, 50, 100]
R = 1000
E0, G0 = 1000.0, 1000.0
os.makedirs("results", exist_ok=True)

t_start = time.time()
for ib, b0 in enumerate(BETAS):
    for inn, n in enumerate(NS):
        fn = f"results/p1_b{b0}_n{n}.npz"
        if os.path.exists(fn):
            print(f"skip {fn}", flush=True); continue
        seeds = np.random.SeedSequence([20260610, 1, ib, inn]).spawn(R)
        out = {m: np.full((R, 4), np.nan) for m in ("mdm01", "mdm00", "mle", "lsm")}
        st = {m: np.empty(R, dtype="U24") for m in out}
        for j, s in enumerate(seeds):
            t = gen_weibull3(np.random.default_rng(s), b0, E0, G0, n)
            for m, f in (("mdm01", mdm_fit(t, offset=0.1)),
                         ("mdm00", mdm_fit(t, offset=0.0)),
                         ("mle", mle3_fit(t)),
                         ("lsm", lsm3_fit(t))):
                out[m][j] = [f["beta"], f["eta"], f["gamma"], f["b10"]]
                st[m][j] = f["status"]
        np.savez(fn, **out, **{m + "_st": st[m] for m in st})
        print(f"P1 b={b0} n={n} done  {time.time()-t_start:.0f}s", flush=True)
print("PHASE1 DONE", flush=True)

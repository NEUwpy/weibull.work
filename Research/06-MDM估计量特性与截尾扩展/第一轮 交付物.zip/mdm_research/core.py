# -*- coding: utf-8 -*-
"""
core.py — 三参数Weibull分布参数估计核心模块
MDM(最小差异法)实现严格遵循《MDM方法计算说明》:
  - Bernard中位秩 F_i=(i-0.3)/(n+0.4), x_i=-ln(1-F_i)
  - 伪尺度 eta_i = (t_(i)-gamma)/x_i^(1/beta)
  - 内层: beta* = argmin_{beta in [0.1,15]} std(eta_i)   (有界一维优化)
  - 外层廓线: S(gamma)=min_beta sigma; 梯度 g=S'(gamma) 有限差分(中心,边界单侧)
  - offset-root判据: 求 g(gamma)=offset (默认0.1)
  - 工程求解器: 探测g(0) -> 截断或几何加密找右锚点 -> brentq(xtol=1e-8,rtol=1e-10) -> gamma*=max(.,0)
"""
import numpy as np
from scipy.optimize import brentq, minimize_scalar, minimize

BETA_LO, BETA_HI = 0.1, 15.0
_K = 140
_BETA_GRID = np.geomspace(BETA_LO, BETA_HI, _K)
_INVB = 1.0 / _BETA_GRID
LN9 = -np.log(0.9)  # B10: gamma + eta * LN9**(1/beta)

def bernard_x(n):
    i = np.arange(1, n + 1)
    F = (i - 0.3) / (n + 0.4)
    return -np.log1p(-F)

_BX_CACHE = {}
def bernard_x_cached(n):
    if n not in _BX_CACHE:
        _BX_CACHE[n] = bernard_x(n)
    return _BX_CACHE[n]

def b10_of(beta, eta, gamma):
    return gamma + eta * LN9 ** (1.0 / beta)

# ---------------- 黄金分割一维最小化(快速内层精化) ----------------
_GR = 0.5 * (np.sqrt(5.0) - 1.0)
def golden_min(f, a, b, iters=22):
    c = b - _GR * (b - a); d = a + _GR * (b - a)
    fc, fd = f(c), f(d)
    for _ in range(iters):
        if fc < fd:
            b, d, fd = d, c, fc
            c = b - _GR * (b - a); fc = f(c)
        else:
            a, c, fc = c, d, fd
            d = a + _GR * (b - a); fd = f(d)
    return (c, fc) if fc < fd else (d, fd)

# ---------------- MDM 工作对象 ----------------
class MDMWork:
    """t_obs: 观测到的(最小的r个)次序统计量; n_total: 总样本量(II型/I型截尾时 > r)."""
    def __init__(self, t_obs, n_total=None):
        t = np.sort(np.asarray(t_obs, dtype=float))
        self.t = t
        self.r = len(t)
        self.n = int(n_total) if n_total is not None else self.r
        x = bernard_x_cached(self.n)[: self.r]
        self.lnx = np.log(x)
        # 预计算 beta 网格上的 x^{-1/beta}: (K, r)
        self.W = np.exp(-np.outer(_INVB, self.lnx))
        self.t1 = t[0]
        self.scale = max(abs(self.t1), 1.0)
        self.h_nom = self.scale * 1e-5   # §10.3 标称差分步长
        self.nS = 0  # S评估计数

    def sigma_scalar(self, beta, gamma):
        eta = (self.t - gamma) * np.exp(-self.lnx / beta)
        return eta.std(ddof=1)

    def inner_min(self, gamma):
        """固定gamma, 求 beta*=argmin sigma(beta|gamma): 网格粗定位+黄金分割精化."""
        self.nS += 1
        E = (self.t - gamma)[None, :] * self.W
        s = E.std(axis=1, ddof=1)
        j = int(np.argmin(s))
        lo = _BETA_GRID[max(j - 1, 0)]
        hi = _BETA_GRID[min(j + 1, _K - 1)]
        b, sv = golden_min(lambda bb: self.sigma_scalar(bb, gamma), lo, hi)
        if s[j] < sv:
            b, sv = _BETA_GRID[j], s[j]
        return b, sv

    def S(self, gamma):
        return self.inner_min(gamma)[1]

    def g(self, gamma):
        """廓线梯度(§10.3): 按左右可用空间自适应选择差分方式与步长."""
        right = max(self.t1 - gamma, 0.0)
        if right <= 0.0:
            return np.inf
        left = max(gamma, 0.0)
        hn = self.h_nom
        if gamma <= 0.0 or left <= hn:          # 前向差分
            h = min(hn, right * 0.25)
            return (self.S(gamma + h) - self.S(gamma)) / h
        if right <= hn:                          # 后向差分
            h = min(hn, left * 0.25, right * 0.5)
            return (self.S(gamma) - self.S(gamma - h)) / h
        h = min(hn, left * 0.25, right * 0.25)   # 中心差分
        return (self.S(gamma + h) - self.S(gamma - h)) / (2.0 * h)

    def inner_min_ref(self, gamma):
        """参考实现: scipy.optimize.minimize_scalar(bounded), 与说明文档一致."""
        res = minimize_scalar(lambda bb: self.sigma_scalar(bb, gamma),
                              bounds=(BETA_LO, BETA_HI), method="bounded",
                              options={"xatol": 1e-7})
        return float(res.x), float(res.fun)


def _mdm_solve(w, offset, inner):
    """offset-root工程求解流程(说明文档§6-7与补充§10)."""
    bs_cache = {}                       # §10.8 gamma -> (beta*, sigma)
    def innerc(gam):
        if gam not in bs_cache:
            bs_cache[gam] = inner(gam)
        return bs_cache[gam]
    Sfun = lambda gam: innerc(gam)[1]
    g_cache = {}                        # §10.8 gamma -> gradient
    def g(gam):
        if gam in g_cache:
            return g_cache[gam]
        right = max(w.t1 - gam, 0.0)
        if right <= 0.0:
            val = np.inf
        else:
            left = max(gam, 0.0)
            hn = w.h_nom
            if gam <= 0.0 or left <= hn:        # §10.3 前向
                h = min(hn, right * 0.25)
                val = (Sfun(gam + h) - Sfun(gam)) / h
            elif right <= hn:                    # 后向
                h = min(hn, left * 0.25, right * 0.5)
                val = (Sfun(gam) - Sfun(gam - h)) / h
            else:                                # 中心
                h = min(hn, left * 0.25, right * 0.25)
                val = (Sfun(gam + h) - Sfun(gam - h)) / (2.0 * h)
        g_cache[gam] = val
        return val

    status = "root"
    if g(0.0) >= offset:                # 情况A: 根在γ≤0, 截断
        gam = 0.0
        status = "trunc0"
    else:                               # 情况B: 找右锚点 (§10.4)
        # 从 t_min-1e-3·|t_min| 向 t_min-1e-12·|t_min| 几何加密探测24点,
        # 取首个 g>=offset 的点为右锚; 全部<offset 时记录最靠近t_min的点.
        min_gap = max(abs(w.t1) * 1e-12, 1e-12)
        gaps = np.geomspace(max(abs(w.t1) * 1e-3, min_gap), min_gap, 24)
        anchor = None
        best = None
        for gap in gaps:
            gp = max(0.0, w.t1 - gap)
            gr = g(gp)
            if best is None or gp > best[0]:
                best = (gp, gr)
            if gr >= offset:
                anchor = (gp, gr)
                break
        if anchor is not None:          # B1: Brent求根
            gam = brentq(lambda x: g(x) - offset, 0.0, anchor[0],
                         xtol=1e-8, rtol=1e-10, maxiter=80)
            gam = max(gam, 0.0)
        else:                           # B2: 右端渐近 (§10.5, 极罕见)
            gam = float(np.nextafter(w.t1, 0.0))
            status = "right_edge"
    beta, _ = innerc(gam)
    eta = float(np.mean((w.t - gam) * np.exp(-w.lnx / beta)))
    return {"beta": float(beta), "eta": eta, "gamma": float(gam),
            "b10": b10_of(beta, eta, gam), "status": status}


def build_geometric_gamma_grid(t_min, gamma_steps=60):
    """§10.1 诊断/可视化用几何加密γ网格: 从靠近t_min到0."""
    steps = max(4, int(gamma_steps))
    min_gap = max(abs(t_min) * 1e-9, 1e-12)
    gaps = np.geomspace(min_gap, t_min, steps)
    gammas = t_min - gaps
    gammas[0] = t_min - min_gap
    gammas[-1] = 0.0
    return gammas


def find_offset_crossing(gammas, gradients, offset):
    """§10.2 离散变号检测+线性插值定根(诊断/可视化用); 多交点取最靠近t_min者."""
    diffs = np.asarray(gradients, float) - offset
    cand = [i for i in range(len(diffs) - 1)
            if diffs[i] == 0 or diffs[i + 1] == 0 or diffs[i] * diffs[i + 1] < 0]
    if not cand:
        return None, diffs
    idx = max(cand, key=lambda i: max(gammas[i], gammas[i + 1]))
    y1, y2 = diffs[idx], diffs[idx + 1]
    x1, x2 = gammas[idx], gammas[idx + 1]
    if y1 == 0:
        gam = float(x1)
    elif y2 == 0:
        gam = float(x2)
    elif y2 != y1:
        gam = float(x1 - y1 * (x2 - x1) / (y2 - y1))
    else:
        gam = float(x1)
    return gam, diffs


def mdm_fit(t_obs, n_total=None, offset=0.1, reference=False):
    """MDM估计. t_obs为观测失效时间(完全样本或II/I型截尾下最小的r个), n_total为总样本量."""
    w = MDMWork(t_obs, n_total)
    if w.r < 4:
        return {"beta": np.nan, "eta": np.nan, "gamma": np.nan,
                "b10": np.nan, "status": "too_few"}
    inner = w.inner_min_ref if reference else w.inner_min
    return _mdm_solve(w, offset, inner)

# ---------------- 三参数 Weibull MLE (廓线法) ----------------
def _mle2_shifted(z_fail, z_cens=None, blo=0.02, bhi=300.0):
    """固定gamma后的二参数Weibull MLE(支持右截尾). 返回(beta, eta, loglik)."""
    zf = np.asarray(z_fail, float)
    r = len(zf)
    za = zf if z_cens is None or len(z_cens) == 0 else np.concatenate([zf, np.asarray(z_cens, float)])
    zmax = za.max()
    zfn = zf / zmax; zan = za / zmax
    lf = np.log(zfn); la = np.log(zan)
    mlf = lf.mean()
    def psi(b):
        p = zan ** b
        return float((p * la).sum() / p.sum() - 1.0 / b - mlf)
    plo, phi = psi(blo), psi(bhi)
    flag = ""
    if plo >= 0.0:
        b = blo; flag = "beta_lo"
    elif phi <= 0.0:
        b = bhi; flag = "beta_hi"
    else:
        b = brentq(psi, blo, bhi, xtol=1e-10, rtol=1e-12)
    eta_n = ((zan ** b).sum() / r) ** (1.0 / b)
    eta = eta_n * zmax
    ll = r * np.log(b) - r * b * np.log(eta) + (b - 1.0) * np.log(zf).sum() - r
    return b, eta, float(ll), flag

def mle3_fit(t_fail, cens_value=None, n_cens=0):
    """三参数Weibull MLE: gamma廓线 + 内层闭式/求根.
    cens_value: 右截尾时间(II型为t_(r), I型为tau), n_cens为截尾数."""
    t = np.sort(np.asarray(t_fail, float))
    r = len(t)
    if r < 3:
        return {"beta": np.nan, "eta": np.nan, "gamma": np.nan, "b10": np.nan, "status": "too_few"}
    t1 = t[0]
    grid = np.unique(np.concatenate([
        np.linspace(0.0, 0.9 * t1, 50),
        t1 - np.geomspace(1e-7 * t1, 0.1 * t1, 30)]))
    grid = grid[(grid >= 0.0) & (grid < t1)]
    def prof(gam):
        zc = None if cens_value is None else np.full(n_cens, cens_value - gam)
        b, e, ll, fl = _mle2_shifted(t - gam, zc)
        return ll, b, e, fl
    lls = np.array([prof(g)[0] for g in grid])
    # 内点局部极大
    loc = [i for i in range(1, len(grid) - 1) if lls[i] >= lls[i-1] and lls[i] >= lls[i+1]]
    status = "interior"
    if loc:
        i = loc[int(np.argmax(lls[loc]))]
        a, bnd = grid[max(i-1, 0)], grid[min(i+1, len(grid)-1)]
        gam, _ = golden_min(lambda x: -prof(x)[0], a, bnd, iters=18)
    else:
        i = int(np.argmax(lls))
        gam = float(grid[i])
        status = "boundary" if i >= len(grid) - 2 else "grid_max"
    ll, b, e, fl = prof(gam)
    if fl:
        status += "_" + fl
    return {"beta": float(b), "eta": float(e), "gamma": float(gam),
            "b10": b10_of(b, e, gam), "status": status}

# ---------------- 三参数 LSM (中位秩回归, 相关系数最大化定gamma) ----------------
def lsm3_fit(t_obs, n_total=None):
    t = np.sort(np.asarray(t_obs, float))
    r = len(t)
    if r < 3:
        return {"beta": np.nan, "eta": np.nan, "gamma": np.nan, "b10": np.nan, "status": "too_few"}
    n = int(n_total) if n_total is not None else r
    y = np.log(bernard_x_cached(n)[:r])
    t1 = t[0]
    def negR2(gam):
        u = np.log(t - gam)
        c = np.corrcoef(u, y)[0, 1]
        return -c * c
    grid = np.unique(np.concatenate([
        np.linspace(0.0, 0.9 * t1, 40),
        t1 - np.geomspace(1e-7 * t1, 0.1 * t1, 25)]))
    grid = grid[(grid >= 0.0) & (grid < t1)]
    vals = np.array([negR2(g) for g in grid])
    i = int(np.argmin(vals))
    a, bnd = grid[max(i-1, 0)], grid[min(i+1, len(grid)-1)]
    gam, _ = golden_min(negR2, a, bnd, iters=18)
    gam = max(gam, 0.0)
    status = "boundary" if i >= len(grid) - 2 else "interior"
    u = np.log(t - gam)
    slope, intercept = np.polyfit(u, y, 1)
    beta = float(slope)
    eta = float(np.exp(-intercept / slope))
    return {"beta": beta, "eta": eta, "gamma": float(gam),
            "b10": b10_of(beta, eta, gam), "status": status}

# ---------------- 区间截尾 ----------------
def interval_data(t, edges):
    """edges: 检查时点(升序). 返回各区间计数m(len k)与末次检查后的右截尾数."""
    k = len(edges)
    m = np.zeros(k, dtype=int)
    prev = 0.0
    for j, e in enumerate(edges):
        m[j] = int(np.sum((t > prev) & (t <= e)))
        prev = e
    mc = int(np.sum(t > edges[-1]))
    return m, mc

def _impute_midpoints(m, edges):
    vals, lo = [], 0.0
    for j, e in enumerate(edges):
        if m[j] > 0:
            vals.extend([0.5 * (lo + e)] * m[j])
        lo = e
    return np.array(vals)

def _impute_quantiles(m, edges, beta, eta, gamma):
    def cdf(x):
        z = (x - gamma) / eta
        return 0.0 if z <= 0 else 1.0 - np.exp(-z ** beta)
    def icdf(p):
        return gamma + eta * (-np.log1p(-p)) ** (1.0 / beta)
    vals, lo = [], 0.0
    for j, e in enumerate(edges):
        if m[j] > 0:
            pa, pb = cdf(lo), cdf(e)
            if pb - pa < 1e-12:
                vals.extend([0.5 * (lo + e)] * m[j])
            else:
                for q in (pa + (np.arange(m[j]) + 0.5) / m[j] * (pb - pa)):
                    v = icdf(min(max(q, 1e-12), 1 - 1e-12))
                    vals.append(min(max(v, lo + 1e-9 * (e - lo)), e))
        lo = e
    return np.array(vals)

def mdm_interval_fit(m, mc, edges, offset=0.1, em_iters=0):
    """区间截尾MDM: em_iters=0为中点插补; >0为EM式分位插补迭代."""
    n_total = int(m.sum() + mc)
    vals = _impute_midpoints(m, edges)
    if len(vals) < 4:
        return {"beta": np.nan, "eta": np.nan, "gamma": np.nan, "b10": np.nan, "status": "too_few"}
    fit = mdm_fit(vals, n_total=n_total, offset=offset)
    for _ in range(em_iters):
        if not np.isfinite(fit["beta"]):
            break
        vals = _impute_quantiles(m, edges, fit["beta"], fit["eta"], fit["gamma"])
        fit = mdm_fit(vals, n_total=n_total, offset=offset)
    return fit

def mle_interval_fit(m, mc, edges, init=None):
    """区间截尾参数化MLE: gamma廓线 + (ln beta, ln eta) Nelder-Mead."""
    m = np.asarray(m, int)
    if m.sum() < 3:
        return {"beta": np.nan, "eta": np.nan, "gamma": np.nan, "b10": np.nan, "status": "too_few"}
    nz = np.nonzero(m)[0]
    gmax = edges[nz[0]]  # gamma必须小于首个非空区间上界
    lo_edges = np.concatenate([[0.0], edges[:-1]])
    def negll(params, gam):
        lb, le = params
        b, e = np.exp(lb), np.exp(le)
        if not (0.01 < b < 500 and e > 0):
            return 1e12
        za = np.maximum(edges - gam, 0.0) / e
        zl = np.maximum(lo_edges - gam, 0.0) / e
        Fa = -np.expm1(-za ** b)
        Fl = -np.expm1(-zl ** b)
        p = Fa - Fl
        Sc = np.exp(-(np.maximum(edges[-1] - gam, 0.0) / e) ** b) if mc > 0 else 1.0
        if np.any(p[m > 0] <= 0):
            return 1e12
        ll = float((m[m > 0] * np.log(p[m > 0])).sum())
        if mc > 0:
            if Sc <= 0:
                return 1e12
            ll += mc * np.log(Sc)
        return -ll
    if init is None or not np.isfinite(init[0]):
        init = (1.5, np.median(edges))
    x0 = np.array([np.log(init[0]), np.log(max(init[1], 1e-6))])
    grid = np.linspace(0.0, gmax * 0.995, 25)
    best = (np.inf, None, None)
    xcur = x0.copy()
    for gam in grid:
        res = minimize(negll, xcur, args=(gam,), method="Nelder-Mead",
                       options={"xatol": 1e-5, "fatol": 1e-8, "maxiter": 250})
        if res.fun < best[0]:
            best = (res.fun, gam, res.x.copy())
        if np.isfinite(res.fun) and res.fun < 1e11:
            xcur = res.x
    _, gam, xb = best
    if xb is None:
        return {"beta": np.nan, "eta": np.nan, "gamma": np.nan, "b10": np.nan, "status": "fail"}
    b, e = float(np.exp(xb[0])), float(np.exp(xb[1]))
    return {"beta": b, "eta": e, "gamma": float(gam),
            "b10": b10_of(b, e, gam), "status": "ok"}

# ---------------- 数据生成 ----------------
def gen_weibull3(rng, beta, eta, gamma, n):
    return gamma + eta * rng.weibull(beta, n)

def quantile_w3(p, beta, eta, gamma):
    return gamma + eta * (-np.log1p(-p)) ** (1.0 / beta)

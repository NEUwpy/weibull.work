# MDM三参数Weibull参数估计 — 蒙特卡洛研究脚本包

## 环境要求
- Python 3.10+，依赖：numpy、scipy、pandas、matplotlib
- 单核CPU即可运行；全部阶段总耗时约80~100分钟（与CPU性能有关）

## 文件说明
| 文件 | 作用 |
|------|------|
| core.py    | 估计器核心：MDM（严格按《MDM方法计算说明》实现）、三参数MLE（γ廓线法）、LSM（相关系数最大化）、II型/I型/区间截尾适配、数据生成 |
| phase0.py  | 阶段0：实现验证（理想样本还原、快速vs参考实现一致性、原文情形复现、等变性、偏移值敏感性、计时） |
| phase1.py  | 阶段1：偏差规律。β0∈{1.5,2,3,4}×n∈{5,10,20,50,100}×1000次重复；方法：MDM(0.1)/MDM(0)/MLE/LSM |
| phase2.py  | 阶段2：截尾。2A=II型（q∈{0,0.2,0.4,0.6}）、2B=I型定时（p∈{0.5,0.7,0.9}）、2C=区间截尾（k∈{4,6,8}，中点/EM插补×区间MLE） |
| phase3.py  | 阶段3：参数化bootstrap置信区间（percentile/basic/BCa，B=199，外层M=300，4个格点）+非参数bootstrap对照；支持格点内断点续跑 |
| analyze.py | 汇总：生成results/*.csv、figs/*.png（中文图）与results/report_data.json |
| make_report.js | 读取report_data.json与figs/生成Word报告（需Node.js + `npm i -g docx`） |

## 运行顺序
```bash
python3 phase0.py      # ~2分钟
python3 phase1.py      # ~11分钟（断点续跑：已有npz自动跳过）
python3 phase2.py      # ~20分钟
python3 phase3.py      # ~55分钟（每25个外层样本保存断点）
python3 analyze.py     # ~1分钟
node make_report.js    # 生成 MDM研究报告.docx
```

## 关键约定
- 真值配置：γ0=η0=1000（位移比γ0/η0=1），β0>1（不含β≤1）
- MDM按计算说明文档：Bernard中位秩、内层β∈[0.1,15]、offset-root判据（默认偏移0.1）、γ≥0截断
- 相对偏差/相对RMSE基准：β̂以β0、η̂与γ̂以η0=1000、B10以其真值为分母
- 随机种子：numpy SeedSequence([20260610, 阶段号, 格点索引…])，全部结果可精确复现
- 结果文件：results/p1_*.npz、p2t2_*/p2t1_*/p2int_*.npz、p3_*.npz（含每次重复的四元组估计与状态码）

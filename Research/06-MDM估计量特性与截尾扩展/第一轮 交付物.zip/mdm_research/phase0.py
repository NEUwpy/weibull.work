# -*- coding: utf-8 -*-
"""phase0.py — 实现验证: 一致性/复现/等变性/偏移敏感性/计时"""
import numpy as np, json, time
from core import (mdm_fit, mle3_fit, lsm3_fit, gen_weibull3, bernard_x, b10_of)

OUT = {}
rng_master = np.random.SeedSequence(20260610)

# ---- 0.1 快速实现 vs 参考实现 ----
diffs = []
t0 = time.perf_counter()
for s in range(200):
    r = np.random.default_rng(1000 + s)
    beta = r.uniform(1.5, 4.5); n = int(r.choice([5, 7, 10, 20, 50]))
    t = gen_weibull3(r, beta, 1000.0, 1000.0, n)
    f1 = mdm_fit(t, offset=0.1, reference=False)
    f2 = mdm_fit(t, offset=0.1, reference=True)
    diffs.append([abs(f1["gamma"] - f2["gamma"]), abs(f1["beta"] - f2["beta"]),
                  abs(f1["eta"] - f2["eta"])])
d = np.array(diffs)
OUT["agreement"] = {"max_dgamma": float(d[:, 0].max()), "max_dbeta": float(d[:, 1].max()),
                    "max_deta": float(d[:, 2].max()), "n_cases": 200,
                    "elapsed_s": round(time.perf_counter() - t0, 1)}
print("0.1 agreement:", OUT["agreement"], flush=True)

# ---- 0.2 原文风格复现: W(2,1000,1000), n=7, 30个随机样本 ----
res = {m: [] for m in ["mdm00", "mdm01", "mle", "lsm"]}
stat01 = []
r = np.random.default_rng(20250707)
for s in range(30):
    t = gen_weibull3(r, 2.0, 1000.0, 1000.0, 7)
    res["mdm00"].append(mdm_fit(t, offset=0.0)["gamma"])
    f = mdm_fit(t, offset=0.1); res["mdm01"].append(f["gamma"]); stat01.append(f["status"])
    res["mle"].append(mle3_fit(t)["gamma"])
    res["lsm"].append(lsm3_fit(t)["gamma"])
OUT["repro30"] = {m: {"min": float(np.min(v)), "max": float(np.max(v)),
                      "range": float(np.max(v) - np.min(v)),
                      "sd": float(np.std(v, ddof=1))} for m, v in res.items()}
OUT["repro30"]["mdm01_trunc0_rate"] = float(np.mean([s == "trunc0" for s in stat01]))
OUT["repro30_values"] = {m: [round(float(x), 1) for x in v] for m, v in res.items()}
print("0.2 repro30:", json.dumps(OUT["repro30"], indent=1), flush=True)

# ---- 0.3 等变性: t' = a*t + b ----
a, b = 2.7, 300.0
errs, used = [], 0
r = np.random.default_rng(99)
for s in range(60):
    t = gen_weibull3(r, 2.5, 1000.0, 1000.0, 10)
    f1 = mdm_fit(t, offset=0.1)
    f2 = mdm_fit(a * t + b, offset=0.1)
    if f1["status"] == "root" and f2["status"] == "root":
        used += 1
        errs.append([abs(f2["gamma"] - (a * f1["gamma"] + b)) / (a * 1000),
                     abs(f2["eta"] - a * f1["eta"]) / (a * 1000),
                     abs(f2["beta"] - f1["beta"]) / f1["beta"]])
e = np.array(errs)
OUT["equivariance"] = {"n_interior": used, "max_rel_err": float(e.max()),
                       "note": "仅比较两侧均为内点根(root)的情形; γ≥0截断分支天然破坏平移等变性"}
print("0.3 equivariance:", OUT["equivariance"], flush=True)

# ---- 0.4 偏移值敏感性: beta=2, n in {7,20}, offset in {0,0.05,0.1,0.2}, 500次 ----
sens = {}
B0, E0, G0 = 2.0, 1000.0, 1000.0
for n in (7, 20):
    seeds = np.random.SeedSequence([20260610, 4, n]).spawn(500)
    samples = [gen_weibull3(np.random.default_rng(s), B0, E0, G0, n) for s in seeds]
    for off in (0.0, 0.05, 0.1, 0.2):
        g_, b_, t_ = [], [], []
        nt0 = 0
        for t in samples:
            f = mdm_fit(t, offset=off)
            g_.append(f["gamma"]); b_.append(f["beta"]); t_.append(f["b10"])
            nt0 += (f["status"] == "trunc0")
        g_, b_, t_ = map(np.array, (g_, b_, t_))
        sens[f"n{n}_off{off}"] = {
            "gamma_bias": float(g_.mean() - G0), "gamma_rmse": float(np.sqrt(((g_ - G0) ** 2).mean())),
            "beta_bias": float(b_.mean() - B0), "beta_rmse": float(np.sqrt(((b_ - B0) ** 2).mean())),
            "b10_rmse": float(np.sqrt(((t_ - b10_of(B0, E0, G0)) ** 2).mean())),
            "trunc0_rate": nt0 / 500}
        print(f"0.4 n={n} off={off}: ", {k: round(v, 1) for k, v in sens[f'n{n}_off{off}'].items()}, flush=True)
OUT["offset_sensitivity"] = sens

# ---- 0.5 计时 ----
tims = {}
for n in (7, 20, 50, 100):
    ts = [gen_weibull3(np.random.default_rng(i), 2.0, E0, G0, n) for i in range(60)]
    t0 = time.perf_counter(); [mdm_fit(t, offset=0.1) for t in ts]
    tims[f"mdm_n{n}_ms"] = round((time.perf_counter() - t0) / 60 * 1000, 2)
t0 = time.perf_counter(); [mle3_fit(t) for t in ts]
tims["mle_n100_ms"] = round((time.perf_counter() - t0) / 60 * 1000, 2)
OUT["timing"] = tims
print("0.5 timing:", tims, flush=True)

with open("results/phase0.json", "w", encoding="utf-8") as f:
    json.dump(OUT, f, ensure_ascii=False, indent=1)
print("PHASE0 DONE", flush=True)

// make_report.js — 生成中文Word研究报告（读取 results/report_data.json 与 figs/*.png）
const fs = require("fs");
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, ImageRun,
  Footer, AlignmentType, LevelFormat, TableOfContents, HeadingLevel,
  BorderStyle, WidthType, ShadingType, PageNumber, PageBreak,
} = require("docx");

const RD = JSON.parse(fs.readFileSync("results/report_data.json", "utf8"));
const KV = RD.kv || {};
const TB = RD.tables || {};

// ---------- 工具 ----------
const kv = (k, d = null) => (KV[k] === undefined || KV[k] === null ? d : KV[k]);
const nm = (x, d = 1) => (x === null || x === undefined || !isFinite(x) ? "—" : Number(x).toFixed(d));
const cmpWord = (a, b, tol = 0.05) => {
  if (a === null || b === null) return "对比";
  const r = a / b;
  if (r < 1 - tol) return "低于";
  if (r > 1 + tol) return "高于";
  return "接近";
};
function pngSize(file) {
  const b = fs.readFileSync(file);
  return { w: b.readUInt32BE(16), h: b.readUInt32BE(20) };
}
const BODY_FONT = { ascii: "Times New Roman", hAnsi: "Times New Roman", eastAsia: "宋体" };
const HEAD_FONT = { ascii: "Arial", hAnsi: "Arial", eastAsia: "黑体" };
const CONTENT_W = 9026; // A4 - 2*1440

const T = (text, o = {}) => new TextRun({ text, font: BODY_FONT, size: o.size || 21, bold: o.bold, italics: o.italics, color: o.color });
const P = (x, o = {}) =>
  new Paragraph({
    children: typeof x === "string" ? [T(x, o)] : x,
    alignment: o.align || AlignmentType.JUSTIFIED,
    spacing: { after: o.after === undefined ? 120 : o.after, before: o.before || 0, line: 300 },
    indent: o.noindent ? undefined : { firstLine: o.firstLine === undefined ? 420 : o.firstLine },
  });
const H = (lvl, text) =>
  new Paragraph({
    heading: [HeadingLevel.HEADING_1, HeadingLevel.HEADING_2, HeadingLevel.HEADING_3][lvl - 1],
    children: [new TextRun({ text, font: HEAD_FONT })],
  });
const BULLET = (text) =>
  new Paragraph({ numbering: { reference: "bul", level: 0 }, children: [T(text)], spacing: { after: 60, line: 280 } });
const NUMIT = (text, ref) =>
  new Paragraph({ numbering: { reference: ref, level: 0 }, children: [T(text)], spacing: { after: 60, line: 280 } });

let figN = 0, tabN = 0;
function Fig(file, caption, maxW = 580) {
  const out = [];
  if (!fs.existsSync(file)) return [P(`【图缺失: ${file}】`, { color: "CC0000" })];
  const { w, h } = pngSize(file);
  const dispW = Math.min(maxW, Math.round(w * 0.62));
  const dispH = Math.round((h * dispW) / w);
  figN += 1;
  out.push(new Paragraph({
    alignment: AlignmentType.CENTER, spacing: { before: 120, after: 40 },
    children: [new ImageRun({ type: "png", data: fs.readFileSync(file),
      transformation: { width: dispW, height: dispH },
      altText: { title: `图${figN}`, description: caption, name: `fig${figN}` } })],
  }));
  out.push(new Paragraph({
    alignment: AlignmentType.CENTER, spacing: { after: 160 },
    children: [T(`图${figN}  ${caption}`, { size: 18 })],
  }));
  return out;
}
function Tbl(name, fontSize = 17, capOverride = null) {
  const t = TB[name];
  if (!t) return [P(`【表缺失: ${name}】`, { color: "CC0000" })];
  tabN += 1;
  const ncol = t.header.length;
  const cw = Math.floor(CONTENT_W / ncol);
  const widths = Array(ncol).fill(cw);
  widths[ncol - 1] = CONTENT_W - cw * (ncol - 1);
  const bd = { style: BorderStyle.SINGLE, size: 2, color: "999999" };
  const borders = { top: bd, bottom: bd, left: bd, right: bd };
  const mkCell = (txt, i, head) =>
    new TableCell({
      borders, width: { size: widths[i], type: WidthType.DXA },
      shading: head ? { fill: "DCE6F1", type: ShadingType.CLEAR } : undefined,
      margins: { top: 40, bottom: 40, left: 70, right: 70 },
      children: [new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 0, line: 240 },
        children: [new TextRun({ text: String(txt), font: BODY_FONT, size: fontSize, bold: head })] })],
    });
  const rows = [new TableRow({ tableHeader: true, children: t.header.map((h, i) => mkCell(h, i, true)) })];
  for (const r of t.rows) rows.push(new TableRow({ children: r.map((c, i) => mkCell(c, i, false)) }));
  return [
    new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 120, after: 60 },
      children: [T(`表${tabN}  ${capOverride || t.title}`, { size: 18 })] }),
    new Table({ width: { size: CONTENT_W, type: WidthType.DXA }, columnWidths: widths, rows }),
    new Paragraph({ children: [], spacing: { after: 120 } }),
  ];
}
const PB = () => new Paragraph({ children: [new PageBreak()] });

// 从已格式化表格中取数(字符串->数值)
function tblNum(name, rowMatch, col) {
  const t = TB[name];
  if (!t) return null;
  for (const r of t.rows) {
    let ok = true;
    for (const [i, v] of Object.entries(rowMatch)) if (String(r[i]) !== String(v)) { ok = false; break; }
    if (ok) { const x = parseFloat(r[col]); return isFinite(x) ? x : null; }
  }
  return null;
}

// ---------- 内容 ----------
const ch = [];

// 封面
ch.push(new Paragraph({ spacing: { before: 2600 }, children: [] }));
ch.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 300 },
  children: [new TextRun({ text: "基于统计最小差异原理（MDM）的三参数Weibull分布参数估计", font: HEAD_FONT, size: 40, bold: true })] }));
ch.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 600 },
  children: [new TextRun({ text: "偏差规律、截尾适应性与置信区间构造的系统蒙特卡洛研究", font: HEAD_FONT, size: 30 })] }));
ch.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 200 },
  children: [T("研究报告", { size: 26 })] }));
ch.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 120 },
  children: [T("实现依据：《MDM方法计算流程说明》及其第10节补充细则", { size: 21 })] }));
ch.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 120 },
  children: [T("方法原文：谢里阳等，《基于统计最小差异原理的Weibull分布参数估计方法》", { size: 21 })] }));
ch.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 1800 },
  children: [T("2026年6月", { size: 24 })] }));
ch.push(PB());

// 目录
ch.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 200 },
  children: [new TextRun({ text: "目  录", font: HEAD_FONT, size: 32, bold: true })] }));
ch.push(new TableOfContents("目录", { hyperlink: true, headingStyleRange: "1-2" }));
ch.push(P("（在Word中全选后按F9可更新目录页码）", { size: 18, color: "808080", align: AlignmentType.CENTER, noindent: true }));
ch.push(PB());

// ============ 摘要 ============
ch.push(H(1, "摘要"));
ch.push(P([
  T("本报告以可复现的蒙特卡洛实验，系统研究了基于统计最小差异原理（Minimum Difference Method, MDM）的三参数Weibull分布参数估计方法。"),
  T("实现严格遵循《MDM方法计算流程说明》：Bernard中位秩、内层β∈[0.1,15]有界优化、廓线梯度的offset-root判据（偏移值固定0.1）、γ≥0截断，以及第10节补充细则规定的自适应差分步长、24点近端右锚点探测、Brent精确求根（xtol=10⁻⁸、maxiter=80）与右端渐近兜底。"),
]));
ch.push(P([
  T(`研究回答三个问题。其一，偏差规律：完全样本下（β0∈{1.5,2,3,4}，n∈{5,…,100}，每格1000次重复），偏移0.1判据使γ̂在小样本下呈正偏（β0=2、n=10时约${nm(kv("gb_mdm01_2.0_10"))}%，以η0为基准），随n增大单调衰减（n=100时约${nm(kv("gb_mdm01_2.0_100"))}%）；而零判据（offset=0）的γ̂呈显著负偏并伴随高比例的γ̂=0边界截断，证实了偏移判据的纠偏价值。各目标量RMSE按n的幂律收敛，MDM(0.1)的γ̂RMSE衰减指数平均约${nm(kv("slope_mdm01_gamma_mean"), 2)}，B10寿命的估计精度与MLE${cmpWord(kv("br_mdm01_2.0_10"), kv("br_mle_2.0_10"))}。`),
]));
ch.push(P([
  T(`其二，截尾适应性：II型截尾下MDM以"前r个次序统计量+全样本量秩"的自然方式工作，截尾比例q≤0.4时性能退化温和；I型定时截尾在截止时间过早（p=0.5）且n较小时出现不可行样本（失效数<4），构成硬性适用边界；区间截尾下，中点插补的朴素MDM存在系统性偏差，EM式分位插补可大幅修正并接近区间MLE。`),
]));
ch.push(P([
  T(`其三，置信区间：MDM缺乏解析渐近方差，本报告构造参数化bootstrap区间（B=199，外层M=300验证覆盖率）。覆盖率普遍低于名义水平且随样本量改善：percentile法90%双侧区间的实际覆盖率中位数约${nm(kv("cov90_percentile_med"), 2)}（n=10偏低、n=30已接近名义），在四个目标量上最为均衡；basic法在γ上明显劣化，与γ̂=0边界堆积有关。B10单侧95%下限在小样本下亦欠覆盖（实际约0.74～0.87），平均下限约为真值的九成，须提高名义水平或增大重抽样数后审慎使用。`),
]));
ch.push(P("关键词：三参数Weibull分布；最小差异法；位置参数；偏差；截尾；bootstrap置信区间", { bold: true }));
ch.push(PB());

// ============ 1 引言 ============
ch.push(H(1, "1  引言与研究设计"));
ch.push(H(2, "1.1  背景与方法回顾"));
ch.push(P([
  T("三参数Weibull分布 F(t)=1−exp{−[(t−γ)/η]^β}（t>γ）广泛用于含最小寿命（位置参数γ）的可靠性建模。其参数估计长期面临两类困难：一是似然函数关于γ的非正则性（γ→t"),
  T("(1)", { size: 14 }),
  T("时似然可发散），二是γ与β、η之间强烈的误差补偿，使各类方法的γ̂呈现大方差与厚尾。"),
]));
ch.push(P([
  T("MDM（最小差异法）的出发点是：对给定(β,γ)，每个次序统计量t"),
  T("(i)", { size: 14 }),
  T("可反解出一个伪尺度估计 η̂"),
  T("i", { size: 14 }),
  T("=(t"),
  T("(i)", { size: 14 }),
  T("−γ)/x"),
  T("i", { size: 14 }),
  T("^(1/β)，其中x"),
  T("i", { size: 14 }),
  T("=−ln(1−F"),
  T("i", { size: 14 }),
  T(")由中位秩F"),
  T("i", { size: 14 }),
  T("=(i−0.3)/(n+0.4)给出。参数取真值时各η̂"),
  T("i", { size: 14 }),
  T("应彼此一致，故以伪尺度标准差σ(β|γ)为目标，内层求β*(γ)=argmin σ，外层得廓线S(γ)=σ(β*(γ)|γ)。"),
]));
ch.push(P([
  T("方法的关键创新在判据：不取廓线极小点（该处梯度为零、曲线平坦、定位方差大），而是求解梯度等于小正偏移值的位置 g(γ)=S′(γ)=offset（本研究固定offset=0.1）。原文在W(2,1000,1000)、n=7的30个随机样本上显示：零判据γ̂范围0～1475，偏移0.1后收窄至约500～1550，而MLE为0～1691、最小二乘法（LSM）为0～1686。本报告第3章在相同设定下复现并核对了这一现象。"),
]));
ch.push(H(2, "1.2  研究问题"));
ch.push(NUMIT("偏差规律：MDM（偏移0.1）的参数估计偏差在什么条件下为正/为负？量级如何随形状参数β0与样本量n变化？随n衰减的速率（衰减指数）是多少？与MLE、LSM相比如何？", "numq"));
ch.push(NUMIT("截尾适应性：II型截尾、I型定时（右）截尾、I型区间截尾下MDM的表现如何？适用边界（可行性与精度可接受的截尾程度）在哪里？", "numq"));
ch.push(NUMIT("区间估计：MDM无解析方差与渐近分布理论，如何构造置信区间？参数化bootstrap各变体（percentile/basic/BCa）的实际覆盖率是否达到名义水平？对工程上最关心的B10寿命，单侧置信下限是否可靠？", "numq"));
ch.push(H(2, "1.3  总体设计与约定"));
ch.push(BULLET("真值配置：γ0=η0=1000（位移比γ0/η0=1，与原文算例一致）；形状参数限定β0>1（不研究β≤1的非正则区）。"));
ch.push(BULLET("γ̂的相对偏差与相对RMSE以η0=1000为基准（由于γ0=η0，数值上亦等于相对γ0的百分数）；β̂以β0、η̂以η0、B10以其真值为基准。"));
ch.push(BULLET("B10寿命 B10=γ+η·(−ln0.9)^(1/β) 作为第四个评估目标量纳入全部阶段。"));
ch.push(BULLET("随机数采用numpy SeedSequence分层派生（主种子20260610），全部结果可逐格点精确复现；各格点重复次数：阶段1为1000、阶段2为800（区间截尾500）、阶段3外层300。"));
ch.push(BULLET("与原文的两点已声明差异（均来自《计算说明》的约定）：中位秩采用Bernard近似而非F分布精确中位秩；γ搜索显式限定γ≥0并以截断处理负根。第8章讨论其影响。"));
ch.push(BULLET("关于MLE偏差规律的对照文档182-029未能获得，本报告的MLE基准为同一设计下自行计算的廓线MLE（第2.2节），保证与MDM逐格点可比。"));

// ============ 2 方法与实现 ============
ch.push(PB());
ch.push(H(1, "2  方法与实现"));
ch.push(H(2, "2.1  MDM求解器（按《计算说明》§1–§10）"));
ch.push(P("内层：固定γ，在β∈[0.1,15]上最小化σ(β|γ)。快速实现采用140点对数网格粗定位加黄金分割精化；并以scipy.optimize.minimize_scalar（bounded）作为参考实现，二者一致性见第3.1节。外层：廓线梯度g(γ)按§10.3以有限差分计算，标称步长h=max(|t(1)|,1)×10⁻⁵，并按左右可用空间取h=min(标称步长, 左侧空间/4, 右侧空间/4)，γ≤0或左侧空间不足时前向差分、右侧不足时后向差分、否则中心差分。"));
ch.push(P("求根决策树（§10.6）：先探测g(0)。若g(0)≥offset，根落在γ≤0，输出截断解γ̂=0（状态trunc0）；否则按§10.4自t(1)−10⁻³·t(1)向t(1)−10⁻¹²·t(1)几何加密探测24点，取首个g≥offset者为右锚点，在[0,锚点]上以Brent法（xtol=10⁻⁸、rtol=10⁻¹⁰、maxiter=80）求解g(γ)=offset（状态root）；若24点全部g<offset（极罕见），按§10.5取右端渐近解γ̂=nextafter(t(1),0)（状态right_edge）。最终γ*=max(γ̂,0)，回代β*=β*(γ*)、η̂=mean(η̂ᵢ)。"));
ch.push(P("依据§10.8设置两级缓存（γ→(β*,σ)与γ→梯度）避免重复求值；§10.1的60点几何γ网格与§10.2的离散变号检测+线性插值实现为诊断/可视化工具，与Brent主路径的对照见第3.1节。"));
ch.push(H(2, "2.2  三参数MLE（基准之一）"));
ch.push(P("对固定γ，二参数Weibull MLE化为β的一维方程ψ(β)=Σz^β ln z/Σz^β − 1/β − mean(ln z)=0（z=t−γ，数据按最大值归一化防溢出），以brentq在[0.02,300]上求根，η̂闭式回代；右截尾时采用标准截尾似然的对应方程。对γ的廓线在[0,t(1))上取80点（含t(1)近端几何加密），优先选取内点局部极大并黄金精化；若廓线向t(1)单调上升（嵌入分布非正则性所致）则取边界并标记boundary。报告统计boundary与β触界比例。"));
ch.push(H(2, "2.3  三参数LSM（基准之二）"));
ch.push(P("中位秩回归：y=ln x 对 u=ln(t−γ) 回归，γ由相关系数R²(γ)最大化确定（同样网格+黄金精化，γ≥0），斜率给出β̂、截距给出η̂。"));
ch.push(H(2, "2.4  截尾数据的适配"));
ch.push(BULLET("II型截尾（前r个失效）：MDM使用前r个次序统计量与全样本量n的Bernard秩，σ与η̂仅对r个伪尺度计算；要求r≥4。MLE用标准II型截尾似然（截尾值t(r)）。"));
ch.push(BULLET("I型定时（右）截尾（截止时间τ）：失效数R为随机量；R<4判为不可行样本并统计可行率，估计性能在可行样本上条件评估。MLE截尾值为τ。"));
ch.push(BULLET("I型区间截尾（k个检查时点，等概率分位设置）：MDM不能直接使用计数数据，研究两种插补变体——中点插补（每区间失效取区间中点）与EM式分位插补（以当前拟合分布把区间内失效摆到条件等概率分位上，迭代3次，中点解热启动）；基准为区间数据的参数化MLE（γ廓线25点×内层Nelder-Mead）。"));
ch.push(H(2, "2.5  评估指标"));
ch.push(P("各格点报告：平均偏差与中位偏差（相对%）、标准差、RMSE（相对%）、偏度、边界/截断发生率；收敛速率以log(RMSE)对log(n)的OLS斜率（衰减指数）刻画，|偏差|的衰减指数仅在偏差显著（|偏差|>2×蒙特卡洛标准误）的点数≥4时拟合。蒙特卡洛标准误（MCSE）随表格在附件CSV中给出。"));

// ============ 3 阶段0 ============
ch.push(PB());
ch.push(H(1, "3  阶段0：实现验证"));
ch.push(H(2, "3.1  正确性与一致性"));
ch.push(P([
  T(`理想样本检验：由Bernard中位秩反算的n=7理想样本（β0=2，η0=γ0=1000）上，零偏移MDM精确还原(2.0, 1000, 1000)；偏移0.1时γ̂=1000.06，仅产生可忽略的判据性平移。快速实现与scipy参考实现在200个随机样本上的最大差异：|Δγ̂|=${Number(kv("agree_dgamma", 0)).toExponential(1)}、|Δβ̂|=${Number(kv("agree_dbeta", 0)).toExponential(1)}、|Δη̂|=${Number(kv("agree_deta", 0)).toExponential(1)}，两实现数值等价。`),
]));
const ac = kv("align_check", {});
ch.push(P([
  T(`§10补充细则对齐前后的求解器对照（300个跨β、n随机样本）：${ac.n_same_1e3 || "—"}/${ac.n_total || "—"}个样本γ̂差异小于10⁻³，其余${ac.n_right_edge ?? "—"}个为§10.5右端渐近出口（占比${ac.n_total ? nm((ac.n_right_edge / ac.n_total) * 100, 1) : "—"}%）。§10.2离散网格诊断与Brent主路径的根定位一致（差异在网格线性插值精度内）。`),
]));
ch.push(P([
  T(`等变性：对位置—尺度变换t′=2.7t+300，内点根（root状态）样本的估计按理论关系变换，最大相对误差${Number(kv("equiv_err", 0)).toExponential(1)}；γ≥0截断分支按设计破坏平移等变性（见第8章讨论）。`),
]));
ch.push(H(2, "3.2  原文情形复现"));
ch.push(P("在W(2,1000,1000)、n=7的30个独立随机样本上重复原文表2型实验（表1）。本实现的γ̂离散程度排序与原文一致：零判据与LSM极差最大（约1570），偏移0.1判据显著收窄（极差约1020、标准差313），MLE居中。与原文具体数值的差异来自随机样本不同及中位秩/下界约定差异，但定性结论完全吻合：偏移判据有效抑制了γ̂的离散。"));
ch.push(...Tbl("t_repro30"));
ch.push(H(2, "3.3  偏移值敏感性（附属分析）"));
ch.push(P("主体研究固定offset=0.1。作为附属分析，表2与图1给出β0=2时偏移值∈{0,0.05,0.1,0.2}的影响：零偏移γ̂强负偏（n=7时约−316）且40%样本截断于γ̂=0；偏移增大使偏差由负转正、RMSE单调下降；B10的RMSE对偏移值几乎不敏感（n=7时约163、n=20时约94），说明偏移主要在γ–β补偿岭上移动解的位置，对寿命分位数影响很小。0.1在偏差与离散之间取得良好平衡，支持原文校准结论。"));
ch.push(...Tbl("t_offset"));
ch.push(...Fig("figs/fig_offset.png", "偏移值对γ̂偏差与RMSE的影响（β0=2，500次重复）"));
ch.push(H(2, "3.4  计算成本"));
const tim = kv("timing", {});
ch.push(P([
  T(`单次MDM拟合（含完整offset-root流程）约${nm(tim.mdm_n7_ms, 1)}～${nm(tim.mdm_n100_ms, 1)}毫秒（n=7～100，单核），MLE约${nm(tim.mle_n100_ms, 1)}毫秒。全部四阶段（约百万次拟合量级）在单核上约80分钟完成。`),
]));

// ============ 4 阶段1 偏差规律 ============
ch.push(PB());
ch.push(H(1, "4  阶段1：偏差规律（问题一）"));
ch.push(H(2, "4.1  γ̂的偏差：方向、量级与随n衰减"));
{
  const g210 = kv("gb_mdm01_2.0_10"), g2100 = kv("gb_mdm01_2.0_100");
  const z210 = kv("gb_mdm00_2.0_10");
  ch.push(P([
    T(`图2与表3给出γ̂相对偏差随n的变化。MDM(0.1)在小样本下呈正偏并随n单调衰减：β0=2时由n=10的约${nm(g210)}%降至n=100的约${nm(g2100)}%；正偏幅度随β0增大而增大——β0=1.5时n≥10即近乎无偏，β0=4时n=10约+29%、n=100仍残留约+10%。零判据MDM(0)则在全部格点呈负偏（β0=2、n=10约${nm(z210)}%），且伴随大量γ̂=0截断（表6），体现“极小点判据+下界截断”联合导致的系统性低估；偏移0.1把解从平坦的极小点移动到具有确定斜率的一段，符号代价是小样本与高β0下的正偏。MLE的γ̂在小样本下大幅正偏、β0≥3的较大样本下转为近无偏或轻度负偏，LSM整体负偏且离散度最大。`),
  ]));
}
ch.push(...Fig("figs/fig_p1_bias_gamma.png", "γ̂相对偏差随样本量的变化（按β0分面；以η0=1000为基准）"));
ch.push(...Tbl("t_p1_gamma_bias"));
ch.push(H(2, "4.2  β̂与B10寿命"));
ch.push(P("图3与表4：MDM(0.1)的β̂在小样本下呈轻度负偏（与γ̂正偏构成补偿，见4.5节），量级普遍小于MLE的β̂正偏；B10寿命由于γ–β–η误差的相互抵消，对所有方法都远比单个参数稳定，MDM(0.1)与MLE的B10精度在全部格点上同量级。这说明若工程目标是寿命分位数而非参数本身，判据细节的影响有限。"));
ch.push(...Fig("figs/fig_p1_bias_beta.png", "β̂相对偏差随样本量的变化（按β0分面）"));
ch.push(...Tbl("t_p1_beta_b10"));
ch.push(H(2, "4.3  RMSE与收敛速率"));
{
  const s_g = kv("slope_mdm01_gamma_mean"), s_b = kv("slope_mdm01_b10_mean");
  const s_gm = kv("slope_mle_gamma_mean");
  ch.push(P([
    T(`图4、图5给出γ̂与B10的相对RMSE（双对数坐标），表5为各方法的衰减指数。MDM(0.1)的γ̂RMSE衰减指数平均约${nm(s_g, 2)}（MLE约${nm(s_gm, 2)}），B10约${nm(s_b, 2)}，均呈良好幂律；|γ̂偏差|的衰减指数在偏差显著的格点上平均约${nm(kv("slope_mdm01_gbias_mean"), 2)}，偏差比RMSE衰减更快，意味着大样本下MDM(0.1)的误差以方差为主。`),
  ]));
}
ch.push(...Fig("figs/fig_p1_rmse_gamma.png", "γ̂相对RMSE随样本量的变化（双对数；图内标注MDM(0.1)拟合斜率）"));
ch.push(...Fig("figs/fig_p1_rmse_b10.png", "B10相对RMSE随样本量的变化（双对数）"));
ch.push(...Tbl("t_decay"));
ch.push(H(2, "4.4  抽样分布形态与边界发生率"));
ch.push(P("图6对比β0=2、n=10下三种判据/方法的γ̂抽样分布：零判据呈“γ̂=0堆积+右侧长尾”的双峰形态；偏移0.1基本消除堆积，分布右移、集中；MLE无0堆积但左尾厚。表6给出全部格点的边界发生率：MDM(0.1)的γ̂=0截断率在各格点均极低（仅n=5时非零、约0.3～1.4%），而MDM(0)的γ̂=0截断率随β0增大而上升（β0大时位移比效应弱、廓线顶点更易落在0左侧）、随n增大而下降——这正是零判据系统性负偏的来源；MLE的边界解（γ̂→t(1)）集中于小样本。右端渐近（right_edge）出口在全部约8万次拟合中占比不足1%，与§10.5“极罕见”定位一致。"));
ch.push(...Fig("figs/fig_p1_dist_gamma.png", "γ̂抽样分布对比（β0=2，n=10）"));
ch.push(...Tbl("t_p1_rates"));
ch.push(H(2, "4.5  误差补偿结构"));
ch.push(P([
  T(`图7给出MDM(0.1)在β0=2、n=20处(γ̂误差, β̂误差)散点：二者呈强负相关（r=${nm(kv("corr_bg_b2n20_mdm01"), 2)}），构成沿“γ增大—β减小”方向的补偿岭。该结构解释了两件事：单参数（尤其γ）的判据敏感与厚尾来自岭向自由度；而B10等寿命分位数沿岭近似不变，故对判据与样本扰动稳健。完整相关系数表见附件p1_corr.csv。`),
]));
ch.push(...Fig("figs/fig_p1_scatter.png", "γ̂与β̂误差的补偿结构（MDM(0.1)，β0=2，n=20）", 430));
ch.push(H(2, "4.6  问题一小结"));
ch.push(BULLET("方向：偏移0.1判据下γ̂小样本正偏、β̂轻度负偏；零判据γ̂系统性负偏并伴随高截断率；MLE的γ̂负偏、β̂正偏。"));
ch.push(BULLET("量级：γ̂正偏随β0增大而增大、随n增大而衰减；衰减快于RMSE，故大样本误差以方差为主。"));
ch.push(BULLET("对比：γ̂的RMSE上MDM(0.1)全面优于LSM、小样本优于MLE；B10精度与MLE同量级，工程意义上的寿命估计两者可互换。"));

// ============ 5 阶段2 截尾 ============
ch.push(PB());
ch.push(H(1, "5  阶段2：截尾方案下的表现与适用边界（问题二）"));
ch.push(H(2, "5.1  II型截尾"));
ch.push(P("设定：β0∈{2,3.5}，n∈{10,20,30}，截尾比例q∈{0,0.2,0.4,0.6}（保留r=n(1−q)个最早失效），每格800次。图8与表7（n=20）显示：q≤0.4时MDM(0.1)的γ̂正偏与B10 RMSE仅温和上升，与截尾MLE保持同量级；q增大到0.6时γ̂正偏继续加重（β0=3.5、q=0.6约+38%），但B10 RMSE并未随之恶化（在中等q升高后趋稳），表明截尾信息损失主要沿γ–β补偿岭转移、对寿命分位数冲击有限。值得注意的是，在β0=3.5下MDM的γ̂ RMSE明显低于MLE（MLE在高形状参数下γ估计离散更大），而二者B10精度始终相当。MDM在II型截尾下无需任何结构修改（前r个伪尺度+全n秩，全程无γ̂=0截断），是其工程友好之处。"));
ch.push(...Fig("figs/fig_p2t2.png", "II型截尾：γ̂偏差、γ̂RMSE与B10 RMSE随截尾比例的变化（n=20）"));
ch.push(...Tbl("t_p2t2"));
ch.push(H(2, "5.2  I型定时（右）截尾：可行性是硬边界"));
{
  const f1p = kv("t1_feas_p05_n10"), f2p = kv("t1_feas_p05_n20");
  ch.push(P([
    T(`设定：截止时间τ取真分布p分位，p∈{0.5,0.7,0.9}。失效数R为随机量，R<4即不可行。可行率主要由期望失效数np决定：图9左显示p=0.5且n=10时（np≈5）可行率约${f1p === null ? "—" : nm(f1p * 100, 0)}%（β0=2），是唯一明显低于满额的格点；n=20（np≈10）即升至约${f2p === null ? "—" : nm(f2p * 100, 0)}%，而p≥0.7或n≥20时可行率均接近100%。在可行样本上（图9右、表8），MDM与MLE的B10精度差距不大，p越小（信息越少）两法误差越大且γ̂正偏加重——这是“早截止+小样本”下界截断与秩信息缺失共同作用的结果。`),
  ]));
}
ch.push(...Fig("figs/fig_p2t1.png", "I型定时截尾：可行率（左）与B10相对RMSE（右，n=20，条件于可行）"));
ch.push(...Tbl("t_p2t1"));
ch.push(H(2, "5.3  I型区间截尾：插补方式决定成败"));
ch.push(P("设定：k∈{4,6,8}个等概率检查时点，n∈{15,30}，每格500次；末次检查后为右截尾。图10与表9（n=30）：中点插补的朴素MDM存在严重系统性负偏（首区间中点取(0,τ1]中点、往往远低于γ0，直接把最小观测值拉低，γ̂偏差达−50%～−97%且不随k消失）；EM式分位插补（以当前拟合分布把区间内失效摆到条件等概率分位，迭代3次、中点解热启动）将γ̂负偏大幅压缩，B10 RMSE随之降到接近区间MLE的水平——β0=3.5下EM与区间MLE几乎相当，β0=2下EM仍略逊于MLE但远优于中点法。结论：区间数据上MDM必须配合模型化插补使用，推荐EM式分位插补；若对γ本身精度要求高，区间MLE仍是更稳的选择。"));
ch.push(...Fig("figs/fig_p2int.png", "区间截尾：γ̂偏差与B10 RMSE随检查时点数k的变化（n=30）"));
ch.push(...Tbl("t_p2int"));
ch.push(H(2, "5.4  适用边界汇总"));
ch.push(NUMIT("II型截尾：q≤0.4（保留比例≥60%）时MDM(0.1)可直接使用，γ̂正偏与B10精度均与截尾MLE同量级；q=0.6时γ̂正偏较大，若以B10等寿命分位数为目标仍可接受，若需γ本身则慎用或增大n。", "numb"));
ch.push(NUMIT("I型定时截尾：要求期望失效数np≥8（经验值，保证可行率高且条件偏差可控）；p=0.5且n≤10的早截止方案不建议使用MDM。", "numb"));
ch.push(NUMIT("区间截尾：禁止中点插补直接套用；EM式分位插补（3次迭代）后MDM可用，k≥6时与区间MLE相当。", "numb"));

// ============ 6 阶段3 置信区间 ============
ch.push(PB());
ch.push(H(1, "6  阶段3：bootstrap置信区间（问题三）"));
ch.push(H(2, "6.1  构造方法"));
ch.push(P("由于MDM缺乏解析方差与渐近分布，采用参数化bootstrap：以(β̂,η̂,γ̂)生成B=199个再抽样数据集并重估，构造percentile、basic与BCa（偏差校正加速，加速常数由n次刀切估计）三种双侧区间（90%、95%）及B10的单侧95%置信下限（percentile 5%分位）。覆盖率以外层M=300次独立实验验证（蒙特卡洛标准误约1.7个百分点），格点(β0,n)∈{2,3.5}×{10,30}。另以非参数bootstrap（经验分布重抽样）在(2,30)做对照。"));
ch.push(H(2, "6.2  覆盖率结果"));
{
  const pmed = kv("cov90_percentile_med"), bmed = kv("cov90_basic_med"), cmed = kv("cov90_BCa_med");
  ch.push(P([
    T(`图11与表10、表11汇总实际覆盖率。90%名义水平下，percentile法的覆盖率中位数约${nm(pmed, 2)}，在四个目标量上最为均衡；basic法在γ上显著不足（γ̂=0边界堆积使“2θ̂−分位数”式反演失真），中位数约${nm(bmed, 2)}；BCa中位数约${nm(cmed, 2)}，对β̂的偏差校正略有帮助，但在B=199、γ存在点质量的设定下并不稳定。小样本（n=10）所有方法的γ覆盖率普遍低于名义值，与γ̂分布的厚尾和边界质量一致；n=30时percentile对β、η、B10已接近名义水平。`),
  ]));
}
ch.push(...Fig("figs/fig_p3_cov.png", "名义90%双侧区间的实际覆盖率（按格点分面；虚线为名义水平）"));
ch.push(...Tbl("t_p3_cov90"));
ch.push(...Tbl("t_p3_cov95"));
ch.push(H(2, "6.3  B10单侧置信下限与边界质量"));
ch.push(P("表12给出工程上最常用的B10单侧95%下限。其实际覆盖率（真值不低于所给下限的频率）在四个格点上约为0.74～0.87，均未达到名义0.95，且随n增大改善（n=30达0.84～0.87）；平均下限约为真值的九成（0.905～0.944）。这说明参数化bootstrap的percentile下限在中小样本下偏高（区间偏窄），存在欠覆盖风险，作可靠性下限使用时应提高名义置信水平或增大B。表中同时给出bootstrap分布中γ*=0的平均质量（本配置下普遍很低，仅β0=2、n=10约0.4%），它是γ区间（尤其basic）失真的来源之一。"));
ch.push(...Tbl("t_p3_b10low"));
ch.push(H(2, "6.4  非参数bootstrap对照"));
ch.push(P("表13：n=30、β0=2下，非参数bootstrap的percentile覆盖率在γ与B10上低于参数化版本（γ 0.81对0.85、B10 0.77对0.81），在β上两者相当（约0.94）、η上互有高低。总体而言，对中小样本三参数Weibull问题，参数化bootstrap在关键的位置参数与寿命分位数上覆盖更接近名义，故本报告优先推荐参数化版本；但两者在小样本下均未完全达到名义水平。"));
ch.push(...Tbl("t_p3_np"));
ch.push(H(2, "6.5  推荐做法"));
ch.push(NUMIT("默认推荐：参数化bootstrap + percentile区间，且B=199偏少，建议B≥999以稳定覆盖率；中小样本下实际覆盖率系统性低于名义水平，工程上应据此留出裕度或提高名义水平。", "numr"));
ch.push(NUMIT("γ的区间应连同γ̂=0质量一并报告；避免使用basic法反演γ区间。", "numr"));
ch.push(NUMIT("n≤10时所有γ区间覆盖率系统性不足，建议仅对B10/分位数作区间陈述，或提高名义水平作保守处理。", "numr"));

// ============ 7 结论 ============
ch.push(PB());
ch.push(H(1, "7  结论与工程建议"));
ch.push(NUMIT("实现层面：严格按《计算说明》§1–§10实现的MDM求解器通过了理想样本还原、双实现一致性、等变性与原文情形复现四项验证；§10细则（自适应差分、24点近端锚、Brent、右端渐近）与此前过渡实现在>99%样本上根一致，求解流程“始终有解”。", "numc"));
ch.push(NUMIT("偏差规律：偏移0.1判据将零判据的系统性负偏（伴随γ̂=0高截断率）转换为小样本轻度正偏，并使γ̂ RMSE大幅下降；正偏随β0增大而增大、随n按幂律衰减且快于RMSE，大样本误差以方差为主。", "numc"));
ch.push(NUMIT("与基准对比：γ̂精度MDM(0.1)在小样本优于MLE、全面优于LSM；B10寿命精度与MLE同量级。MDM以中位秩与一维求根实现，无似然非正则性烦恼，工程实施成本低。", "numc"));
ch.push(NUMIT("截尾适用边界：II型q≤0.4直接可用；I型定时要求期望失效数≥8；区间截尾必须采用EM式分位插补。", "numc"));
ch.push(NUMIT("区间估计：推荐参数化bootstrap percentile区间与B10单侧95%下限；γ区间在小样本下覆盖不足，须谨慎陈述。", "numc"));
ch.push(NUMIT("偏移值：0.1贯穿全部研究表现稳健；敏感性分析显示其处于偏差—方差平衡区，且B10对偏移几乎不敏感，无需按β、n微调。", "numc"));

// ============ 8 局限 ============
ch.push(H(1, "8  局限性与说明"));
ch.push(BULLET("中位秩采用Bernard近似（计算说明约定），与原文F分布中位秩存在微小差异，对偏差规律的定性结论无影响，但逐数值对照原文表格时应留意。"));
ch.push(BULLET("γ≥0显式下界与右端渐近兜底来自《计算说明》工程化约定：前者破坏平移等变性并产生γ̂=0点质量（本报告已将其作为统计对象计量），后者在<1%样本中给出γ̂≈t(1)的极端解。"));
ch.push(BULLET("真值配置固定位移比γ0/η0=1（原文算例设定）。位移比显著更小（如0.1）时γ̂=0截断率将上升，偏差规律的常数项会变化，幂律形态预计保持；该外推未在本报告内验证。"));
ch.push(BULLET("阶段3的B=199、M=300为计算预算折中，覆盖率的MCSE约1.7个百分点；BCa在该B下对带点质量的γ分布不稳定，其结论限于本设定。"));
ch.push(BULLET("182-029（MLE偏差规律研究）未获得，无法逐格对齐其参数网格与指标口径；本报告MLE为同设计自算基准。"));
ch.push(BULLET("全部模拟在numpy/scipy双精度下进行；Brent容差(1e-8)远小于统计不确定性，数值误差可忽略。"));

// ============ 附录 ============
ch.push(PB());
ch.push(H(1, "附录A  交付物与复现说明"));
ch.push(P("脚本包（与本报告一并交付）：core.py（MDM/MLE/LSM与截尾适配）、phase0.py～phase3.py（四阶段实验）、analyze.py与augment_kv.py（汇总与制图）、make_report.js（本报告生成器）、README.md（运行顺序与环境）。结果文件：results/p1_*.npz等保存每次重复的全部估计与状态码，p1_summary.csv、p1_decay.csv、p1_corr.csv、p2t2_summary.csv、p2t1_summary.csv、p2int_summary.csv、p3_coverage.csv为汇总表。所有随机数由SeedSequence([20260610, 阶段, 格点索引…])派生，重跑脚本即可逐位复现本报告全部数字。", { noindent: false }));
ch.push(H(1, "附录B  求解器关键参数（§10.9对照）"));
{
  RD.tables["t_params"] = {
    title: "关键参数汇总",
    header: ["参数", "取值", "含义"],
    rows: [
      ["offset", "0.1（固定）", "梯度偏置阈值"],
      ["β搜索范围", "[0.1, 15]", "内层优化bounds"],
      ["差分标称步长", "max(|t(1)|,1)×1e-5", "§10.3，并按两侧空间/4收缩"],
      ["右锚点探测", "24点，距t(1)为1e-3~1e-12·|t(1)|", "§10.4 几何加密"],
      ["Brent容差", "xtol=1e-8, rtol=1e-10, maxiter=80", "§10.9"],
      ["诊断γ网格", "60点几何加密", "§10.1（可视化/对照）"],
      ["无锚兜底", "γ̂=nextafter(t(1),0)", "§10.5 右端渐近"],
      ["MDM最少失效数", "4", "σ与秩信息的最低要求"],
    ],
  };
}
ch.push(...Tbl("t_params"));

// ---------- 汇编 ----------
const doc = new Document({
  creator: "MDM研究管线",
  title: "MDM三参数Weibull参数估计系统蒙特卡洛研究报告",
  styles: {
    default: { document: { run: { font: BODY_FONT, size: 21 } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 30, bold: true, font: HEAD_FONT },
        paragraph: { spacing: { before: 280, after: 200 }, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 26, bold: true, font: HEAD_FONT },
        paragraph: { spacing: { before: 220, after: 140 }, outlineLevel: 1 } },
      { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 22, bold: true, font: HEAD_FONT },
        paragraph: { spacing: { before: 160, after: 100 }, outlineLevel: 2 } },
    ],
  },
  numbering: {
    config: [
      { reference: "bul", levels: [{ level: 0, format: LevelFormat.BULLET, text: "•", alignment: AlignmentType.LEFT,
        style: { paragraph: { indent: { left: 560, hanging: 280 } } } }] },
      ...["numq", "numb", "numr", "numc"].map((r) => ({
        reference: r,
        levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 560, hanging: 280 } } } }],
      })),
    ],
  },
  features: { updateFields: true },
  sections: [{
    properties: {
      page: { size: { width: 11906, height: 16838 },
        margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 } },
    },
    footers: {
      default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER,
        children: [new TextRun({ text: "第 ", font: BODY_FONT, size: 18 }),
          new TextRun({ children: [PageNumber.CURRENT], font: BODY_FONT, size: 18 }),
          new TextRun({ text: " 页", font: BODY_FONT, size: 18 })] })] }),
    },
    children: ch,
  }],
});

Packer.toBuffer(doc).then((buf) => {
  fs.writeFileSync("MDM研究报告.docx", buf);
  console.log("docx written:", buf.length, "bytes; figs:", figN, "tables:", tabN);
});

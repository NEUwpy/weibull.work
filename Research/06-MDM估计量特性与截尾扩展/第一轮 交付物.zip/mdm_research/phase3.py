# -*- coding: utf-8 -*-
"""phase3.py — MDM置信区间: 参数化bootstrap (percentile/basic/BCa) 覆盖率验证
外层M=300, 内层B=199; 目标量 beta/eta/gamma/B10; 双侧90%/95% + B10单侧95%下限.
另含非参数bootstrap对照(1个格点, M=150)."""
import numpy as np, time, os
from scipy.stats import norm
from core import mdm_fit, gen_weibull3, b10_of

E0, G0 = 1000.0, 1000.0
CELLS = [(2.0, 10), (2.0, 30), (3.5, 10), (3.5, 30)]
M, B = 300, 199
TGT = ["beta", "eta", "gamma", "b10"]
LV = [0.90, 0.95]
os.makedirs("results", exist_ok=True)
t_start = time.time()

def fit_vec(t, n_total=None):
    f = mdm_fit(t, n_total=n_total, offset=0.1)
    return np.array([f["beta"], f["eta"], f["gamma"], f["b10"]]), f["status"]

def bca_ci(boot, that, jack, alpha):
    """BCa区间; boot:(B,), that:标量, jack:(n,)"""
    Bn = len(boot)
    p = np.clip(np.mean(boot < that), 0.5 / Bn, 1 - 0.5 / Bn)
    z0 = norm.ppf(p)
    u = jack.mean() - jack
    den = (u ** 2).sum() ** 1.5
    a = (u ** 3).sum() / (6.0 * den) if den > 0 else 0.0
    z = norm.ppf([alpha / 2, 1 - alpha / 2])
    adj = z0 + (z0 + z) / (1 - a * (z0 + z))
    al = np.clip(norm.cdf(adj), 1e-4, 1 - 1e-4)
    return np.quantile(boot, al[0]), np.quantile(boot, al[1])

for b0, n in CELLS:
    fn = f"results/p3_b{b0}_n{n}.npz"
    if os.path.exists(fn):
        print(f"skip {fn}", flush=True); continue
    truth = np.array([b0, E0, G0, b10_of(b0, E0, G0)])
    seeds = np.random.SeedSequence([20260610, 3, int(b0 * 10), n]).spawn(M)
    part = fn.replace(".npz", "_part.npz")
    i0 = 0
    if os.path.exists(part):
        d = np.load(part)
        cover, width = d["cover"], d["width"]
        cover_low, lb_b10 = d["cover_low"], d["lb_b10"]
        thetas, g0mass = d["thetas"], d["g0mass"]
        i0 = int(d["i_done"])
        print(f"resume {part} from {i0}", flush=True)
    else:
        # cover[m, tgt, method(0=pct,1=basic,2=bca), level] ; width 同形
        cover = np.zeros((M, 4, 3, 2), dtype=bool)
        width = np.full((M, 4, 3, 2), np.nan)
        cover_low = np.zeros(M, dtype=bool)   # B10 单侧95%下限
        lb_b10 = np.full(M, np.nan)
        thetas = np.full((M, 4), np.nan)
        g0mass = np.full(M, np.nan)           # bootstrap分布中 gamma*=0 的质量
    for i in range(i0, M):
        s = seeds[i]
        rng = np.random.default_rng(s)
        t = gen_weibull3(rng, b0, E0, G0, n)
        that, _ = fit_vec(t)
        thetas[i] = that
        if not np.all(np.isfinite(that)):
            continue
        bs = np.full((B, 4), np.nan)
        for bb in range(B):
            tb = that[2] + that[1] * rng.weibull(that[0], n)
            bs[bb], _ = fit_vec(tb)
        ok = np.all(np.isfinite(bs), axis=1)
        bs = bs[ok]
        if len(bs) < 50:
            continue
        g0mass[i] = np.mean(bs[:, 2] <= 1e-9)
        # jackknife (供BCa)
        jk = np.full((n, 4), np.nan)
        for d in range(n):
            jk[d], _ = fit_vec(np.delete(t, d), n_total=n - 1)
        jok = np.all(np.isfinite(jk), axis=1)
        for it in range(4):
            bo = bs[:, it]
            for il, lv in enumerate(LV):
                al = 1 - lv
                qlo, qhi = np.quantile(bo, [al / 2, 1 - al / 2])
                # percentile
                cover[i, it, 0, il] = qlo <= truth[it] <= qhi
                width[i, it, 0, il] = qhi - qlo
                # basic
                blo, bhi = 2 * that[it] - qhi, 2 * that[it] - qlo
                cover[i, it, 1, il] = blo <= truth[it] <= bhi
                width[i, it, 1, il] = bhi - blo
                # BCa
                if jok.sum() >= max(4, n - 2):
                    clo, chi = bca_ci(bo, that[it], jk[jok, it], al)
                    cover[i, it, 2, il] = clo <= truth[it] <= chi
                    width[i, it, 2, il] = chi - clo
        lb = np.quantile(bs[:, 3], 0.05)
        lb_b10[i] = lb
        cover_low[i] = lb <= truth[3]
        if (i + 1) % 25 == 0:
            np.savez(part, cover=cover, width=width, cover_low=cover_low,
                     lb_b10=lb_b10, thetas=thetas, g0mass=g0mass, i_done=i + 1)
            print(f"P3 b={b0} n={n}: {i+1}/{M}  {time.time()-t_start:.0f}s", flush=True)
    np.savez(fn, cover=cover, width=width, cover_low=cover_low,
             lb_b10=lb_b10, thetas=thetas, g0mass=g0mass, truth=truth)
    if os.path.exists(part):
        os.remove(part)
    print(f"P3 cell b={b0} n={n} DONE  {time.time()-t_start:.0f}s", flush=True)

# ---- 非参数bootstrap对照: (2.0, 30), percentile ----
b0, n = 2.0, 30
fn = "results/p3np_b2.0_n30.npz"
if not os.path.exists(fn):
    truth = np.array([b0, E0, G0, b10_of(b0, E0, G0)])
    Mnp = 150
    seeds = np.random.SeedSequence([20260610, 39, 20, 30]).spawn(Mnp)
    part = fn.replace(".npz", "_part.npz")
    i0 = 0
    if os.path.exists(part):
        d = np.load(part)
        cover, width, i0 = d["cover"], d["width"], int(d["i_done"])
        print(f"resume {part} from {i0}", flush=True)
    else:
        cover = np.zeros((Mnp, 4, 2), dtype=bool)
        width = np.full((Mnp, 4, 2), np.nan)
    for i in range(i0, Mnp):
        s = seeds[i]
        rng = np.random.default_rng(s)
        t = gen_weibull3(rng, b0, E0, G0, n)
        that, _ = fit_vec(t)
        if not np.all(np.isfinite(that)):
            continue
        bs = np.full((B, 4), np.nan)
        for bb in range(B):
            bs[bb], _ = fit_vec(rng.choice(t, size=n, replace=True))
        ok = np.all(np.isfinite(bs), axis=1)
        bs = bs[ok]
        if len(bs) < 50:
            continue
        for it in range(4):
            for il, lv in enumerate(LV):
                al = 1 - lv
                qlo, qhi = np.quantile(bs[:, it], [al / 2, 1 - al / 2])
                cover[i, it, il] = qlo <= truth[it] <= qhi
                width[i, it, il] = qhi - qlo
        if (i + 1) % 25 == 0:
            np.savez(part, cover=cover, width=width, i_done=i + 1)
            print(f"P3-NP {i+1}/{Mnp}  {time.time()-t_start:.0f}s", flush=True)
    np.savez(fn, cover=cover, width=width, truth=truth)
    if os.path.exists(part):
        os.remove(part)
print("PHASE3 DONE", flush=True)

# -*- coding: utf-8 -*-
"""phase2.py — 截尾方案研究: II型 / I型定时(右) / I型区间截尾"""
import numpy as np, time, os
from core import (mdm_fit, mle3_fit, gen_weibull3, quantile_w3,
                  interval_data, mdm_interval_fit, mle_interval_fit)

E0, G0 = 1000.0, 1000.0
BETAS = [2.0, 3.5]
os.makedirs("results", exist_ok=True)
t_start = time.time()

# ---- 2A: II型截尾 ----
R = 800
for ib, b0 in enumerate(BETAS):
    for inn, n in enumerate([10, 20, 30]):
        for iq, q in enumerate([0.0, 0.2, 0.4, 0.6]):
            r = int(round(n * (1 - q)))
            fn = f"results/p2t2_b{b0}_n{n}_q{q}.npz"
            if os.path.exists(fn):
                print(f"skip {fn}", flush=True); continue
            seeds = np.random.SeedSequence([20260610, 21, ib, inn, iq]).spawn(R)
            out = {m: np.full((R, 4), np.nan) for m in ("mdm01", "mle")}
            st = {m: np.empty(R, dtype="U24") for m in out}
            for j, s in enumerate(seeds):
                t = np.sort(gen_weibull3(np.random.default_rng(s), b0, E0, G0, n))
                tf = t[:r]
                f1 = mdm_fit(tf, n_total=n, offset=0.1)
                f2 = mle3_fit(tf, cens_value=(t[r - 1] if r < n else None),
                              n_cens=(n - r))
                for m, f in (("mdm01", f1), ("mle", f2)):
                    out[m][j] = [f["beta"], f["eta"], f["gamma"], f["b10"]]
                    st[m][j] = f["status"]
            np.savez(fn, **out, **{m + "_st": st[m] for m in st})
            print(f"P2-T2 b={b0} n={n} q={q} done  {time.time()-t_start:.0f}s", flush=True)

# ---- 2B: I型定时(右)截尾 ----
for ib, b0 in enumerate(BETAS):
    for inn, n in enumerate([10, 20, 30]):
        for ip, p in enumerate([0.5, 0.7, 0.9]):
            tau = quantile_w3(p, b0, E0, G0)
            fn = f"results/p2t1_b{b0}_n{n}_p{p}.npz"
            if os.path.exists(fn):
                print(f"skip {fn}", flush=True); continue
            seeds = np.random.SeedSequence([20260610, 22, ib, inn, ip]).spawn(R)
            out = {m: np.full((R, 4), np.nan) for m in ("mdm01", "mle")}
            st = {m: np.empty(R, dtype="U24") for m in out}
            nfail = np.zeros(R, dtype=int)
            for j, s in enumerate(seeds):
                t = np.sort(gen_weibull3(np.random.default_rng(s), b0, E0, G0, n))
                tf = t[t <= tau]
                nfail[j] = len(tf)
                if len(tf) < 4:
                    st["mdm01"][j] = st["mle"][j] = "infeasible"
                    continue
                f1 = mdm_fit(tf, n_total=n, offset=0.1)
                f2 = mle3_fit(tf, cens_value=tau, n_cens=n - len(tf))
                for m, f in (("mdm01", f1), ("mle", f2)):
                    out[m][j] = [f["beta"], f["eta"], f["gamma"], f["b10"]]
                    st[m][j] = f["status"]
            np.savez(fn, **out, nfail=nfail, **{m + "_st": st[m] for m in st})
            print(f"P2-T1 b={b0} n={n} p={p} done  {time.time()-t_start:.0f}s", flush=True)

# ---- 2C: I型区间截尾 ----
R2 = 500
for ib, b0 in enumerate(BETAS):
    for inn, n in enumerate([15, 30]):
        for ik, k in enumerate([4, 6, 8]):
            edges = quantile_w3((np.arange(1, k + 1)) / (k + 1.0), b0, E0, G0)
            fn = f"results/p2int_b{b0}_n{n}_k{k}.npz"
            if os.path.exists(fn):
                print(f"skip {fn}", flush=True); continue
            seeds = np.random.SeedSequence([20260610, 23, ib, inn, ik]).spawn(R2)
            out = {m: np.full((R2, 4), np.nan) for m in ("mdm_mid", "mdm_em", "mle_int")}
            st = {m: np.empty(R2, dtype="U24") for m in out}
            for j, s in enumerate(seeds):
                t = gen_weibull3(np.random.default_rng(s), b0, E0, G0, n)
                m_, mc = interval_data(t, edges)
                f1 = mdm_interval_fit(m_, mc, edges, offset=0.1, em_iters=0)
                f2 = mdm_interval_fit(m_, mc, edges, offset=0.1, em_iters=3)
                ini = (f1["beta"], f1["eta"]) if np.isfinite(f1["beta"]) else None
                f3 = mle_interval_fit(m_, mc, edges, init=ini)
                for m, f in (("mdm_mid", f1), ("mdm_em", f2), ("mle_int", f3)):
                    out[m][j] = [f["beta"], f["eta"], f["gamma"], f["b10"]]
                    st[m][j] = f["status"]
            np.savez(fn, **out, **{m + "_st": st[m] for m in st})
            print(f"P2-INT b={b0} n={n} k={k} done  {time.time()-t_start:.0f}s", flush=True)
print("PHASE2 DONE", flush=True)

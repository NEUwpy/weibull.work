# -*- coding: utf-8 -*-
"""analyze.py — 读取各阶段npz结果, 生成汇总CSV、中文图表与report_data.json"""
import numpy as np, json, os, glob
import pandas as pd
from scipy.stats import skew as _skew
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager

# ---------- 中文字体 ----------
for fp in glob.glob("/usr/share/fonts/opentype/noto/*.ttc"):
    try:
        font_manager.fontManager.addfont(fp)
    except Exception:
        pass
plt.rcParams["font.sans-serif"] = ["Noto Sans CJK SC", "Noto Sans CJK JP", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False
plt.rcParams["figure.dpi"] = 150

LN9 = -np.log(0.9)
E0 = G0 = 1000.0
PARAMS = ["beta", "eta", "gamma", "b10"]
PCN = {"beta": "β", "eta": "η", "gamma": "γ", "b10": "B10"}
MCN = {"mdm01": "MDM(偏移0.1)", "mdm00": "MDM(零判据)", "mle": "MLE", "lsm": "LSM",
       "mdm_mid": "MDM-中点插补", "mdm_em": "MDM-EM插补", "mle_int": "区间MLE"}
MCOL = {"mdm01": "#d62728", "mdm00": "#ff9896", "mle": "#1f77b4", "lsm": "#2ca02c",
        "mdm_mid": "#ff9896", "mdm_em": "#d62728", "mle_int": "#1f77b4"}

def b10_true(b0):
    return G0 + E0 * LN9 ** (1.0 / b0)

def denom(b0):
    """相对量纲: beta/β0, eta/η0, gamma/η0(γ0=η0=1000), b10/B10真值"""
    return np.array([b0, E0, E0, b10_true(b0)])

def truths(b0):
    return np.array([b0, E0, G0, b10_true(b0)])

def summarize(est, b0):
    """est: (R,4). 返回 {param: 指标dict}, 自动忽略NaN行"""
    ok = np.all(np.isfinite(est), axis=1)
    e = est[ok]
    tr, dn = truths(b0), denom(b0)
    out = {}
    for i, p in enumerate(PARAMS):
        d = e[:, i] - tr[i]
        out[p] = {
            "n_ok": int(ok.sum()),
            "bias": float(d.mean()),
            "relbias_pct": float(d.mean() / dn[i] * 100),
            "med_relbias_pct": float(np.median(d) / dn[i] * 100),
            "sd": float(d.std(ddof=1)),
            "rmse": float(np.sqrt((d ** 2).mean())),
            "relrmse_pct": float(np.sqrt((d ** 2).mean()) / dn[i] * 100),
            "skew": float(_skew(d)) if len(d) > 5 else np.nan,
            "mcse_relbias_pct": float(d.std(ddof=1) / np.sqrt(len(d)) / dn[i] * 100),
        }
    return out

def rate(st, key):
    return float(np.mean([key in s for s in st]))

os.makedirs("figs", exist_ok=True)
RD = {"tables": {}, "kv": {}, "missing": []}

def add_table(name, title, header, rows):
    RD["tables"][name] = {"title": title, "header": header, "rows": rows}

def f1(x):  # 1位小数
    return "—" if x is None or not np.isfinite(x) else f"{x:.1f}"
def f2(x):
    return "—" if x is None or not np.isfinite(x) else f"{x:.2f}"
def f3(x):
    return "—" if x is None or not np.isfinite(x) else f"{x:.3f}"

# ====================== Phase 0 ======================
P0 = json.load(open("results/phase0.json", encoding="utf-8"))
RD["kv"]["agree_dgamma"] = P0["agreement"]["max_dgamma"]
RD["kv"]["agree_dbeta"] = P0["agreement"]["max_dbeta"]
RD["kv"]["agree_deta"] = P0["agreement"]["max_deta"]
RD["kv"]["equiv_err"] = P0["equivariance"]["max_rel_err"]
RD["kv"]["timing"] = P0["timing"]

rows = []
for m in ["mdm00", "mdm01", "mle", "lsm"]:
    v = P0["repro30"][m]
    rows.append([MCN[m], f1(v["min"]), f1(v["max"]), f1(v["range"]), f1(v["sd"])])
add_table("t_repro30", "30个随机样本(W(2,1000,1000), n=7)的γ̂统计 — 与原文表2情形对照",
          ["方法", "γ̂最小值", "γ̂最大值", "极差", "标准差"], rows)

rows = []
for n in (7, 20):
    for off in (0.0, 0.05, 0.1, 0.2):
        v = P0["offset_sensitivity"][f"n{n}_off{off}"]
        rows.append([str(n), f2(off), f1(v["gamma_bias"]), f1(v["gamma_rmse"]),
                     f2(v["beta_bias"]), f2(v["beta_rmse"]), f1(v["b10_rmse"]),
                     f1(v["trunc0_rate"] * 100)])
add_table("t_offset", "偏移值敏感性 (β0=2, η0=γ0=1000, 500次重复)",
          ["n", "偏移值", "γ̂偏差", "γ̂ RMSE", "β̂偏差", "β̂ RMSE", "B10 RMSE", "γ̂=0截断率%"], rows)

# 图: 偏移敏感性
fig, axes = plt.subplots(1, 2, figsize=(8.6, 3.4))
offs = [0.0, 0.05, 0.1, 0.2]
for ax, key, ylab in zip(axes, ["gamma_bias", "gamma_rmse"], ["γ̂偏差", "γ̂ RMSE"]):
    for n, mk in ((7, "o-"), (20, "s--")):
        ys = [P0["offset_sensitivity"][f"n{n}_off{o}"][key] for o in offs]
        ax.plot(offs, ys, mk, label=f"n={n}")
    ax.axhline(0, color="gray", lw=0.7)
    ax.set_xlabel("偏移值 offset"); ax.set_ylabel(ylab); ax.legend(); ax.grid(alpha=0.3)
axes[0].set_title("γ̂偏差随偏移值的变化"); axes[1].set_title("γ̂ RMSE随偏移值的变化")
fig.tight_layout(); fig.savefig("figs/fig_offset.png"); plt.close(fig)

# ====================== Phase 1 ======================
BETAS1 = [1.5, 2.0, 3.0, 4.0]
NS1 = [5, 10, 20, 50, 100]
M1 = ["mdm01", "mdm00", "mle", "lsm"]
S1 = {}     # (b0,n,m) -> summary dict
RT = {}     # rates
have_p1 = True
for b0 in BETAS1:
    for n in NS1:
        fn = f"results/p1_b{b0}_n{n}.npz"
        if not os.path.exists(fn):
            RD["missing"].append(fn); have_p1 = False; continue
        d = np.load(fn)
        for m in M1:
            S1[(b0, n, m)] = summarize(d[m], b0)
        RT[(b0, n)] = {
            "mdm01_trunc0": rate(d["mdm01_st"], "trunc0"),
            "mdm00_trunc0": rate(d["mdm00_st"], "trunc0"),
            "mdm01_fallback": rate(d["mdm01_st"], "fallback") + rate(d["mdm01_st"], "right_edge"),
            "mle_boundary": rate(d["mle_st"], "boundary"),
            "mle_betacap": rate(d["mle_st"], "beta_"),
            "lsm_boundary": rate(d["lsm_st"], "boundary"),
        }

if have_p1:
    # 汇总CSV
    recs = []
    for (b0, n, m), s in S1.items():
        for p in PARAMS:
            recs.append(dict(beta0=b0, n=n, method=m, param=p, **s[p]))
    pd.DataFrame(recs).to_csv("results/p1_summary.csv", index=False)
    pd.DataFrame([dict(beta0=b, n=n, **v) for (b, n), v in RT.items()]
                 ).to_csv("results/p1_rates.csv", index=False)

    # 衰减指数: log RMSE ~ log n; |bias|显著时再拟合 log|bias| ~ log n
    drecs = []
    for m in M1:
        for b0 in BETAS1:
            for p in PARAMS:
                ns = np.array(NS1, float)
                rm = np.array([S1[(b0, n, m)][p]["relrmse_pct"] for n in NS1])
                sl_r = np.polyfit(np.log(ns), np.log(rm), 1)[0]
                bias = np.array([S1[(b0, n, m)][p]["relbias_pct"] for n in NS1])
                mcse = np.array([S1[(b0, n, m)][p]["mcse_relbias_pct"] for n in NS1])
                sig = np.abs(bias) > 2 * mcse
                sl_b = np.polyfit(np.log(ns[sig]), np.log(np.abs(bias[sig])), 1)[0] if sig.sum() >= 4 else np.nan
                drecs.append(dict(method=m, beta0=b0, param=p,
                                  slope_rmse=sl_r, slope_absbias=sl_b, n_sig=int(sig.sum())))
    DD = pd.DataFrame(drecs)
    DD.to_csv("results/p1_decay.csv", index=False)

    # 误差相关(γ-β补偿)
    crecs = []
    for b0 in BETAS1:
        for n in NS1:
            d = np.load(f"results/p1_b{b0}_n{n}.npz")
            for m in ("mdm01", "mle"):
                e = d[m]; ok = np.all(np.isfinite(e), axis=1); e = e[ok]
                cb = np.corrcoef(e[:, 0] - b0, e[:, 2] - G0)[0, 1]
                ce = np.corrcoef(e[:, 1] - E0, e[:, 2] - G0)[0, 1]
                crecs.append(dict(beta0=b0, n=n, method=m, corr_beta_gamma=cb, corr_eta_gamma=ce))
    pd.DataFrame(crecs).to_csv("results/p1_corr.csv", index=False)

    # 报告表: γ̂相对偏差% 与 相对RMSE%
    for key, name, title in (("relbias_pct", "t_p1_gamma_bias", "γ̂相对偏差%（以η0=1000为基准）"),
                             ("relrmse_pct", "t_p1_gamma_rmse", "γ̂相对RMSE%（以η0=1000为基准）")):
        rows = []
        for b0 in BETAS1:
            for n in NS1:
                rows.append([f2(b0), str(n)] + [f1(S1[(b0, n, m)]["gamma"][key]) for m in M1])
        add_table(name, title, ["β0", "n", "MDM(0.1)", "MDM(0)", "MLE", "LSM"], rows)

    rows = []
    for b0 in BETAS1:
        for n in NS1:
            s1, s2 = S1[(b0, n, "mdm01")], S1[(b0, n, "mle")]
            rows.append([f2(b0), str(n),
                         f1(s1["beta"]["relbias_pct"]), f1(s1["beta"]["relrmse_pct"]),
                         f1(s2["beta"]["relbias_pct"]), f1(s2["beta"]["relrmse_pct"]),
                         f1(s1["b10"]["relbias_pct"]), f1(s1["b10"]["relrmse_pct"]),
                         f1(s2["b10"]["relbias_pct"]), f1(s2["b10"]["relrmse_pct"])])
    add_table("t_p1_beta_b10", "β̂与B10的相对偏差/相对RMSE%（MDM(0.1)与MLE）",
              ["β0", "n", "MDM β̂偏差", "MDM β̂RMSE", "MLE β̂偏差", "MLE β̂RMSE",
               "MDM B10偏差", "MDM B10RMSE", "MLE B10偏差", "MLE B10RMSE"], rows)

    rows = []
    for b0 in BETAS1:
        for n in NS1:
            r = RT[(b0, n)]
            rows.append([f2(b0), str(n), f1(r["mdm01_trunc0"] * 100), f1(r["mdm00_trunc0"] * 100),
                         f1(r["mle_boundary"] * 100), f1(r["lsm_boundary"] * 100)])
    add_table("t_p1_rates", "边界/截断发生率%（γ̂=0截断或γ̂→t(1)边界）",
              ["β0", "n", "MDM(0.1)截断", "MDM(0)截断", "MLE边界", "LSM边界"], rows)

    rows = []
    for m in ("mdm01", "mle"):
        for b0 in BETAS1:
            g = DD[(DD.method == m) & (DD.beta0 == b0)]
            def gs(p, c):
                v = g[g.param == p][c].values
                return v[0] if len(v) else np.nan
            rows.append([MCN[m], f2(b0), f2(gs("gamma", "slope_rmse")), f2(gs("beta", "slope_rmse")),
                         f2(gs("eta", "slope_rmse")), f2(gs("b10", "slope_rmse")),
                         f2(gs("gamma", "slope_absbias"))])
    add_table("t_decay", "收敛速率: log(RMSE)~log(n)拟合斜率（越负收敛越快; 末列为|γ̂偏差|衰减指数, 不显著时记—）",
              ["方法", "β0", "γ̂RMSE指数", "β̂RMSE指数", "η̂RMSE指数", "B10RMSE指数", "|γ̂偏差|指数"], rows)
print("analyze: phase0/1 tables done", flush=True)

# ====================== Phase 1 图 ======================
if have_p1:
    for pname, fn_, ylab in (("gamma", "fig_p1_bias_gamma", "γ̂相对偏差 %"),
                             ("beta", "fig_p1_bias_beta", "β̂相对偏差 %")):
        fig, axes = plt.subplots(2, 2, figsize=(9.2, 6.2), sharex=True)
        for ax, b0 in zip(axes.flat, BETAS1):
            for m in M1:
                ys = [S1[(b0, n, m)][pname]["relbias_pct"] for n in NS1]
                ax.plot(NS1, ys, "o-", ms=3.5, lw=1.4, color=MCOL[m], label=MCN[m])
            ax.axhline(0, color="gray", lw=0.8)
            ax.set_xscale("log"); ax.set_title(f"β0={b0}", fontsize=10); ax.grid(alpha=0.3)
        for ax in axes[1]: ax.set_xlabel("样本量 n")
        for ax in axes[:, 0]: ax.set_ylabel(ylab)
        h, l = axes[0, 0].get_legend_handles_labels()
        fig.legend(h, l, ncol=4, loc="upper center", bbox_to_anchor=(0.5, 1.02), fontsize=9)
        fig.tight_layout(rect=(0, 0, 1, 0.95))
        fig.savefig(f"figs/{fn_}.png", bbox_inches="tight"); plt.close(fig)

    for pname, fn_, ylab in (("gamma", "fig_p1_rmse_gamma", "γ̂相对RMSE %"),
                             ("b10", "fig_p1_rmse_b10", "B10相对RMSE %")):
        fig, axes = plt.subplots(2, 2, figsize=(9.2, 6.2), sharex=True)
        for ax, b0 in zip(axes.flat, BETAS1):
            for m in M1:
                ys = [S1[(b0, n, m)][pname]["relrmse_pct"] for n in NS1]
                ax.plot(NS1, ys, "o-", ms=3.5, lw=1.4, color=MCOL[m], label=MCN[m])
            sl = DD[(DD.method == "mdm01") & (DD.beta0 == b0) & (DD.param == pname)]["slope_rmse"].values[0]
            ax.text(0.04, 0.06, f"MDM(0.1)斜率={sl:.2f}", transform=ax.transAxes, fontsize=8.5)
            ax.set_xscale("log"); ax.set_yscale("log")
            ax.set_title(f"β0={b0}", fontsize=10); ax.grid(alpha=0.3, which="both")
        for ax in axes[1]: ax.set_xlabel("样本量 n")
        for ax in axes[:, 0]: ax.set_ylabel(ylab)
        h, l = axes[0, 0].get_legend_handles_labels()
        fig.legend(h, l, ncol=4, loc="upper center", bbox_to_anchor=(0.5, 1.02), fontsize=9)
        fig.tight_layout(rect=(0, 0, 1, 0.95))
        fig.savefig(f"figs/{fn_}.png", bbox_inches="tight"); plt.close(fig)

    # γ̂抽样分布直方图 (β0=2, n=10)
    d = np.load("results/p1_b2.0_n10.npz")
    fig, axes = plt.subplots(1, 3, figsize=(10.5, 3.2), sharey=True)
    for ax, m in zip(axes, ("mdm00", "mdm01", "mle")):
        g = d[m][:, 2]; g = g[np.isfinite(g)]
        ax.hist(g, bins=40, range=(0, 1900), color=MCOL[m], alpha=0.85)
        ax.axvline(1000, color="k", ls="--", lw=1)
        p0 = np.mean(g <= 1e-9) * 100
        ax.set_title(f"{MCN[m]}\nSD={g.std(ddof=1):.0f}, P(γ̂=0)={p0:.0f}%", fontsize=9.5)
        ax.set_xlabel("γ̂")
    axes[0].set_ylabel("频数")
    fig.suptitle("γ̂抽样分布 (β0=2, n=10, 真值γ0=1000)", fontsize=11)
    fig.tight_layout(); fig.savefig("figs/fig_p1_dist_gamma.png", bbox_inches="tight"); plt.close(fig)

    # 误差补偿散点 (β0=2, n=20, MDM(0.1))
    d = np.load("results/p1_b2.0_n20.npz")
    e = d["mdm01"]; ok = np.all(np.isfinite(e), axis=1); e = e[ok]
    xg = (e[:, 2] - G0) / E0 * 100; yb = (e[:, 0] - 2.0) / 2.0 * 100
    cc = np.corrcoef(xg, yb)[0, 1]
    fig, ax = plt.subplots(figsize=(5.0, 4.0))
    ax.scatter(xg, yb, s=6, alpha=0.35, color=MCOL["mdm01"])
    ax.axhline(0, color="gray", lw=0.7); ax.axvline(0, color="gray", lw=0.7)
    ax.set_xlabel("γ̂相对误差 %"); ax.set_ylabel("β̂相对误差 %")
    ax.set_title(f"MDM(0.1)误差补偿结构 (β0=2, n=20), r={cc:.2f}", fontsize=10)
    ax.grid(alpha=0.3)
    fig.tight_layout(); fig.savefig("figs/fig_p1_scatter.png", bbox_inches="tight"); plt.close(fig)
    RD["kv"]["corr_bg_b2n20_mdm01"] = float(cc)
print("analyze: phase1 figs done", flush=True)

# ====================== Phase 2 ======================
B2 = [2.0, 3.5]
# ---- 2A II型截尾 ----
recs, S2 = [], {}
have_t2 = True
for b0 in B2:
    for n in [10, 20, 30]:
        for q in [0.0, 0.2, 0.4, 0.6]:
            fn = f"results/p2t2_b{b0}_n{n}_q{q}.npz"
            if not os.path.exists(fn):
                RD["missing"].append(fn); have_t2 = False; continue
            d = np.load(fn)
            for m in ("mdm01", "mle"):
                s = summarize(d[m], b0); S2[(b0, n, q, m)] = s
                tr = rate(d[m + "_st"], "trunc0") if m == "mdm01" else rate(d[m + "_st"], "boundary")
                for p in PARAMS:
                    recs.append(dict(beta0=b0, n=n, q=q, method=m, param=p, edge_rate=tr, **s[p]))
if recs:
    pd.DataFrame(recs).to_csv("results/p2t2_summary.csv", index=False)
if have_t2:
    rows = []
    for b0 in B2:
        for q in [0.0, 0.2, 0.4, 0.6]:
            for m in ("mdm01", "mle"):
                s = S2[(b0, 20, q, m)]
                rows.append([f2(b0), f2(q), MCN[m],
                             f1(s["gamma"]["relbias_pct"]), f1(s["gamma"]["relrmse_pct"]),
                             f1(s["beta"]["relbias_pct"]), f1(s["beta"]["relrmse_pct"]),
                             f1(s["b10"]["relbias_pct"]), f1(s["b10"]["relrmse_pct"])])
    add_table("t_p2t2", "II型截尾 (n=20, 截尾比例q): 相对偏差/相对RMSE%",
              ["β0", "q", "方法", "γ̂偏差", "γ̂RMSE", "β̂偏差", "β̂RMSE", "B10偏差", "B10RMSE"], rows)
    fig, axes = plt.subplots(2, 3, figsize=(10.8, 6.0), sharex=True)
    qs = [0.0, 0.2, 0.4, 0.6]
    for ir, b0 in enumerate(B2):
        for ic, (p, key, ylab) in enumerate((("gamma", "relbias_pct", "γ̂相对偏差%"),
                                             ("gamma", "relrmse_pct", "γ̂相对RMSE%"),
                                             ("b10", "relrmse_pct", "B10相对RMSE%"))):
            ax = axes[ir, ic]
            for m in ("mdm01", "mle"):
                ys = [S2[(b0, 20, q, m)][p][key] for q in qs]
                ax.plot(qs, ys, "o-", color=MCOL[m], label=MCN[m])
            if key == "relbias_pct": ax.axhline(0, color="gray", lw=0.7)
            ax.grid(alpha=0.3)
            if ir == 0: ax.set_title(ylab, fontsize=10)
            if ir == 1: ax.set_xlabel("截尾比例 q")
            if ic == 0: ax.set_ylabel(f"β0={b0}")
    h, l = axes[0, 0].get_legend_handles_labels()
    fig.legend(h, l, ncol=2, loc="upper center", bbox_to_anchor=(0.5, 1.02))
    fig.suptitle("II型截尾下的估计性能 (n=20)", y=1.06, fontsize=11)
    fig.tight_layout(); fig.savefig("figs/fig_p2t2.png", bbox_inches="tight"); plt.close(fig)

# ---- 2B I型定时截尾 ----
recs, S2b, FR = [], {}, {}
have_t1 = True
for b0 in B2:
    for n in [10, 20, 30]:
        for p_ in [0.5, 0.7, 0.9]:
            fn = f"results/p2t1_b{b0}_n{n}_p{p_}.npz"
            if not os.path.exists(fn):
                RD["missing"].append(fn); have_t1 = False; continue
            d = np.load(fn)
            fr = float(np.mean(np.isfinite(d["mdm01"][:, 0])))
            FR[(b0, n, p_)] = (fr, float(d["nfail"].mean()))
            for m in ("mdm01", "mle"):
                s = summarize(d[m], b0); S2b[(b0, n, p_, m)] = s
                for pp in PARAMS:
                    recs.append(dict(beta0=b0, n=n, p_cens=p_, method=m, param=pp,
                                     feasible_rate=fr, mean_nfail=float(d["nfail"].mean()), **s[pp]))
if recs:
    pd.DataFrame(recs).to_csv("results/p2t1_summary.csv", index=False)
if have_t1:
    rows = []
    for b0 in B2:
        for p_ in [0.5, 0.7, 0.9]:
            fr, mn = FR[(b0, 20, p_)]
            for m in ("mdm01", "mle"):
                s = S2b[(b0, 20, p_, m)]
                rows.append([f2(b0), f2(p_), f1(fr * 100), f1(mn), MCN[m],
                             f1(s["gamma"]["relbias_pct"]), f1(s["gamma"]["relrmse_pct"]),
                             f1(s["b10"]["relbias_pct"]), f1(s["b10"]["relrmse_pct"])])
    add_table("t_p2t1", "I型定时截尾 (n=20, 截止时间为真分布p分位): 可行率与条件性能",
              ["β0", "p", "可行率%", "平均失效数", "方法", "γ̂偏差", "γ̂RMSE", "B10偏差", "B10RMSE"], rows)
    fig, axes = plt.subplots(1, 2, figsize=(9.6, 3.6))
    for b0, ls in ((2.0, "-"), (3.5, "--")):
        for n, mk in ((10, "o"), (20, "s"), (30, "^")):
            ys = [FR[(b0, n, p_)][0] * 100 for p_ in [0.5, 0.7, 0.9]]
            axes[0].plot([0.5, 0.7, 0.9], ys, mk + ls, label=f"β0={b0}, n={n}", ms=4)
    axes[0].set_xlabel("截止时间分位 p"); axes[0].set_ylabel("可行率 %（失效数≥4）")
    axes[0].grid(alpha=0.3); axes[0].legend(fontsize=7.5)
    for b0, ls in ((2.0, "-"), (3.5, "--")):
        for m in ("mdm01", "mle"):
            ys = [S2b[(b0, 20, p_, m)]["b10"]["relrmse_pct"] for p_ in [0.5, 0.7, 0.9]]
            axes[1].plot([0.5, 0.7, 0.9], ys, "o" + ls, color=MCOL[m], label=f"{MCN[m]}, β0={b0}", ms=4)
    axes[1].set_xlabel("截止时间分位 p"); axes[1].set_ylabel("B10相对RMSE %（n=20, 条件于可行）")
    axes[1].grid(alpha=0.3); axes[1].legend(fontsize=7.5)
    fig.suptitle("I型定时截尾", fontsize=11)
    fig.tight_layout(); fig.savefig("figs/fig_p2t1.png", bbox_inches="tight"); plt.close(fig)

# ---- 2C 区间截尾 ----
recs, S2c = [], {}
have_int = True
for b0 in B2:
    for n in [15, 30]:
        for k in [4, 6, 8]:
            fn = f"results/p2int_b{b0}_n{n}_k{k}.npz"
            if not os.path.exists(fn):
                RD["missing"].append(fn); have_int = False; continue
            d = np.load(fn)
            for m in ("mdm_mid", "mdm_em", "mle_int"):
                s = summarize(d[m], b0); S2c[(b0, n, k, m)] = s
                for pp in PARAMS:
                    recs.append(dict(beta0=b0, n=n, k=k, method=m, param=pp, **s[pp]))
if recs:
    pd.DataFrame(recs).to_csv("results/p2int_summary.csv", index=False)
if have_int:
    rows = []
    for b0 in B2:
        for k in [4, 6, 8]:
            for m in ("mdm_mid", "mdm_em", "mle_int"):
                s = S2c[(b0, 30, k, m)]
                rows.append([f2(b0), str(k), MCN[m],
                             f1(s["beta"]["relbias_pct"]), f1(s["gamma"]["relbias_pct"]),
                             f1(s["b10"]["relbias_pct"]), f1(s["b10"]["relrmse_pct"])])
    add_table("t_p2int", "I型区间截尾 (n=30, k个等概率检查时点): 相对偏差/RMSE%",
              ["β0", "k", "方法", "β̂偏差", "γ̂偏差", "B10偏差", "B10RMSE"], rows)
    fig, axes = plt.subplots(2, 2, figsize=(9.0, 6.0), sharex=True)
    ks = [4, 6, 8]
    for ir, b0 in enumerate(B2):
        for ic, (p, key, ylab) in enumerate((("gamma", "relbias_pct", "γ̂相对偏差%"),
                                             ("b10", "relrmse_pct", "B10相对RMSE%"))):
            ax = axes[ir, ic]
            for m in ("mdm_mid", "mdm_em", "mle_int"):
                ys = [S2c[(b0, 30, k, m)][p][key] for k in ks]
                lsty = {"mdm_mid": ":", "mdm_em": "-", "mle_int": "--"}[m]
                ax.plot(ks, ys, "o" + lsty, color=MCOL[m], label=MCN[m])
            if key == "relbias_pct": ax.axhline(0, color="gray", lw=0.7)
            ax.grid(alpha=0.3); ax.set_xticks(ks)
            if ir == 0: ax.set_title(ylab, fontsize=10)
            if ir == 1: ax.set_xlabel("检查时点数 k")
            if ic == 0: ax.set_ylabel(f"β0={b0}")
    h, l = axes[0, 0].get_legend_handles_labels()
    fig.legend(h, l, ncol=3, loc="upper center", bbox_to_anchor=(0.5, 1.02))
    fig.suptitle("区间截尾下的估计性能 (n=30)", y=1.06, fontsize=11)
    fig.tight_layout(); fig.savefig("figs/fig_p2int.png", bbox_inches="tight"); plt.close(fig)
print("analyze: phase2 done", flush=True)

# ====================== Phase 3 覆盖率 ======================
CELLS3 = [(2.0, 10), (2.0, 30), (3.5, 10), (3.5, 30)]
CIM = ["percentile", "basic", "BCa"]
recs, have_p3 = [], True
rows90, rows95, rows_low = [], [], []
for b0, n in CELLS3:
    fn = f"results/p3_b{b0}_n{n}.npz"
    if not os.path.exists(fn):
        RD["missing"].append(fn); have_p3 = False; continue
    d = np.load(fn)
    cover, width = d["cover"], d["width"]
    dn = denom(b0)
    cell_rows = {0: [], 1: []}
    for it, p in enumerate(PARAMS):
        covs = {}
        for ic, cm in enumerate(CIM):
            for il, lv in enumerate([0.90, 0.95]):
                w = width[:, it, ic, il]
                msk = np.isfinite(w)
                cov = float(cover[msk, it, ic, il].mean()) if msk.sum() else np.nan
                rw = float(np.nanmean(w) / dn[it] * 100)
                covs[(ic, il)] = (cov, rw, int(msk.sum()))
                recs.append(dict(beta0=b0, n=n, target=p, ci=cm, level=lv,
                                 coverage=cov, rel_width_pct=rw, n_eff=int(msk.sum())))
        for il, rows_ in ((0, rows90), (1, rows95)):
            rows_.append([f2(b0), str(n), PCN[p]] +
                         [f3(covs[(ic, il)][0]) for ic in range(3)] +
                         [f1(covs[(0, il)][1])])
    msk = np.isfinite(d["lb_b10"])
    cl = float(d["cover_low"][msk].mean()) if msk.sum() else np.nan
    mlb = float(np.nanmean(d["lb_b10"]) / b10_true(b0))
    g0m = float(np.nanmean(d["g0mass"]))
    rows_low.append([f2(b0), str(n), f3(cl), f3(mlb), f1(g0m * 100)])
    RD["kv"][f"g0mass_b{b0}_n{n}"] = g0m
if recs:
    pd.DataFrame(recs).to_csv("results/p3_coverage.csv", index=False)
if have_p3:
    hdr = ["β0", "n", "目标量", "percentile", "basic", "BCa", "pct平均相对宽度%"]
    add_table("t_p3_cov90", "参数化bootstrap双侧90%区间的实际覆盖率 (B=199, 外层M=300)", hdr, rows90)
    add_table("t_p3_cov95", "参数化bootstrap双侧95%区间的实际覆盖率", hdr, rows95)
    add_table("t_p3_b10low", "B10单侧95%置信下限 (percentile)",
              ["β0", "n", "下限覆盖率", "平均下限/真值", "bootstrap中γ*=0平均质量%"], rows_low)
    # 覆盖率图 (90%)
    fig, axes = plt.subplots(2, 2, figsize=(9.6, 6.4), sharey=True)
    xw = np.arange(4)
    for ax, (b0, n) in zip(axes.flat, CELLS3):
        d = np.load(f"results/p3_b{b0}_n{n}.npz")
        cover, width = d["cover"], d["width"]
        for ic, cm in enumerate(CIM):
            covs = []
            for it in range(4):
                w = width[:, it, ic, 0]; msk = np.isfinite(w)
                covs.append(cover[msk, it, ic, 0].mean() if msk.sum() else np.nan)
            ax.bar(xw + (ic - 1) * 0.26, covs, width=0.26, label=cm)
        ax.axhline(0.90, color="k", ls="--", lw=1)
        ax.set_xticks(xw); ax.set_xticklabels([PCN[p] for p in PARAMS])
        ax.set_ylim(0.5, 1.0); ax.set_title(f"β0={b0}, n={n}", fontsize=10); ax.grid(alpha=0.3, axis="y")
    axes[0, 0].set_ylabel("覆盖率"); axes[1, 0].set_ylabel("覆盖率")
    h, l = axes[0, 0].get_legend_handles_labels()
    fig.legend(h, l, ncol=3, loc="upper center", bbox_to_anchor=(0.5, 1.02))
    fig.suptitle("名义90%双侧区间的实际覆盖率（虚线=名义水平）", y=1.07, fontsize=11)
    fig.tight_layout(); fig.savefig("figs/fig_p3_cov.png", bbox_inches="tight"); plt.close(fig)

# 非参数bootstrap对照
fnp = "results/p3np_b2.0_n30.npz"
if os.path.exists(fnp):
    d = np.load(fnp)
    rows = []
    for it, p in enumerate(PARAMS):
        line = [PCN[p]]
        for il, lv in enumerate([0.90, 0.95]):
            w = d["width"][:, it, il]; msk = np.isfinite(w)
            line.append(f3(d["cover"][msk, it, il].mean() if msk.sum() else np.nan))
        rows.append(line)
    add_table("t_p3_np", "非参数bootstrap percentile覆盖率对照 (β0=2, n=30, M=150)",
              ["目标量", "90%覆盖率", "95%覆盖率"], rows)
else:
    RD["missing"].append(fnp)
print("analyze: phase3 done", flush=True)

with open("results/report_data.json", "w", encoding="utf-8") as f:
    json.dump(RD, f, ensure_ascii=False, indent=1, default=float)
print("ANALYZE DONE; missing:", RD["missing"], flush=True)

# ====================== 方法学示意图: 廓线S(γ)与梯度g(γ) ======================
from core import MDMWork, build_geometric_gamma_grid, gen_weibull3 as _gen
_r = np.random.default_rng(50_000 + 145)
_b0 = _r.uniform(1.5, 4.5); _n = int(_r.choice([5, 7, 10, 20, 50]))
_t = 1000 + 1000 * _r.weibull(_b0, _n)
_w = MDMWork(_t)
_gg = np.unique(np.concatenate([np.linspace(0, _w.t1 * 0.997, 70),
                                build_geometric_gamma_grid(_w.t1, 40)]))
_S = np.array([_w.inner_min(x)[1] for x in _gg])
_G = np.array([_w.g(x) for x in _gg])
from core import mdm_fit as _mf
_root = _mf(_t, offset=0.1)["gamma"]
_gmin = float(_gg[int(np.argmin(_S))])
fig, axes = plt.subplots(2, 1, figsize=(7.6, 5.6), sharex=True)
axes[0].plot(_gg, _S, color="#333")
axes[0].axvline(_gmin, color="#ff9896", ls=":", lw=1.3, label="零判据点(廓线极小)")
axes[0].axvline(_root, color="#d62728", ls="--", lw=1.3, label="offset-root(偏移0.1)")
axes[0].set_ylabel("S(γ)=min$_β$ σ"); axes[0].legend(fontsize=8.5); axes[0].grid(alpha=0.3)
axes[0].set_title(f"廓线与offset-root示意（一个W({_b0:.1f},1000,1000)样本, n={_n}, t$_{{(1)}}$={_w.t1:.0f}）", fontsize=10)
axes[1].plot(_gg, _G, color="#1f77b4")
axes[1].axhline(0.1, color="#d62728", ls="--", lw=1, label="offset=0.1")
axes[1].axhline(0, color="gray", lw=0.7)
axes[1].axvline(_root, color="#d62728", ls="--", lw=1.3)
axes[1].set_xlabel("γ"); axes[1].set_ylabel("g(γ)=S'(γ)")
axes[1].legend(fontsize=8.5); axes[1].grid(alpha=0.3)
axes[1].annotate("上升沿根(取此)", xy=(_root, 0.1), xytext=(_root - _w.t1 * 0.3, 0.135),
                 fontsize=8.5, arrowprops=dict(arrowstyle="->", lw=0.8))
fig.tight_layout(); fig.savefig("figs/fig_method_profile.png", bbox_inches="tight"); plt.close(fig)
RD["kv"]["profile_demo"] = {"beta0": float(_b0), "n": int(_n), "t1": float(_w.t1),
                            "gamma_min": _gmin, "gamma_root": float(_root)}
print("analyze: method profile fig done", flush=True)

# ====================== 图片尺寸元数据(供docx嵌图) ======================
figmeta = {}
for fp in sorted(glob.glob("figs/*.png")):
    im = plt.imread(fp)
    figmeta[os.path.basename(fp)] = {"h": int(im.shape[0]), "w": int(im.shape[1])}
with open("figs/figmeta.json", "w") as f:
    json.dump(figmeta, f)
print("figmeta written:", len(figmeta), flush=True)

# -*- coding: utf-8 -*-
"""augment_kv.py — 在analyze.py之后运行: 为报告叙事补充关键数值到report_data.json"""
import numpy as np, json, os, importlib.util
import pandas as pd

RD = json.load(open("results/report_data.json", encoding="utf-8"))
kv = RD["kv"]

# 1) §10对齐前后一致性battery (core_old.py为过渡版实现)
if os.path.exists("core_old.py"):
    def load(name, path):
        spec = importlib.util.spec_from_file_location(name, path)
        m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
        return m
    new = load("corenew_a", "core.py")
    old = load("coreold_a", "core_old.py")
    mx = np.zeros(3); n_edge = 0; n_same = 0
    N = 300
    for s in range(N):
        r = np.random.default_rng(5000 + s)
        b = r.uniform(1.5, 4.5); n = int(r.choice([5, 7, 10, 20, 50]))
        t = new.gen_weibull3(r, b, 1000., 1000., n)
        f1 = new.mdm_fit(t, offset=0.1); f2 = old.mdm_fit(t, offset=0.1)
        d = [abs(f1["gamma"] - f2["gamma"]), abs(f1["beta"] - f2["beta"]), abs(f1["eta"] - f2["eta"])]
        mx = np.maximum(mx, d)
        n_edge += (f1["status"] == "right_edge")
        n_same += (d[0] < 1e-3)
    kv["align_check"] = {"n_total": N, "n_same_1e3": int(n_same), "n_right_edge": int(n_edge),
                         "max_dgamma": float(mx[0]), "max_dbeta": float(mx[1]), "max_deta": float(mx[2])}

# 2) 衰减指数摘要
if os.path.exists("results/p1_decay.csv"):
    dd = pd.read_csv("results/p1_decay.csv")
    for m in ("mdm01", "mle", "lsm"):
        for p in ("gamma", "beta", "b10"):
            g = dd[(dd.method == m) & (dd.param == p)]["slope_rmse"]
            kv[f"slope_{m}_{p}_mean"] = float(g.mean())
            kv[f"slope_{m}_{p}_min"] = float(g.min())
            kv[f"slope_{m}_{p}_max"] = float(g.max())
    g = dd[(dd.method == "mdm01") & (dd.param == "gamma")]["slope_absbias"].dropna()
    if len(g):
        kv["slope_mdm01_gbias_mean"] = float(g.mean())
        kv["slope_mdm01_gbias_n"] = int(len(g))

# 3) P1 关键单元数值 (MDM(0.1) γ̂相对偏差与RMSE)
if os.path.exists("results/p1_summary.csv"):
    s1 = pd.read_csv("results/p1_summary.csv")
    def pick(b0, n, m, p, col):
        g = s1[(s1.beta0 == b0) & (s1.n == n) & (s1.method == m) & (s1.param == p)][col]
        return float(g.values[0]) if len(g) else None
    for b0 in (2.0, 3.0):
        for n in (5, 10, 100):
            kv[f"gb_mdm01_{b0}_{n}"] = pick(b0, n, "mdm01", "gamma", "relbias_pct")
            kv[f"gb_mdm00_{b0}_{n}"] = pick(b0, n, "mdm00", "gamma", "relbias_pct")
            kv[f"gr_mdm01_{b0}_{n}"] = pick(b0, n, "mdm01", "gamma", "relrmse_pct")
            kv[f"gr_mle_{b0}_{n}"] = pick(b0, n, "mle", "gamma", "relrmse_pct")
            kv[f"br_mdm01_{b0}_{n}"] = pick(b0, n, "mdm01", "b10", "relrmse_pct")
            kv[f"br_mle_{b0}_{n}"] = pick(b0, n, "mle", "b10", "relrmse_pct")

# 4) 覆盖率极值与中位 (90%双侧)
if os.path.exists("results/p3_coverage.csv"):
    cc = pd.read_csv("results/p3_coverage.csv")
    for ci in ("percentile", "basic", "BCa"):
        g = cc[(cc.ci == ci) & (cc.level == 0.90)]["coverage"].dropna()
        if len(g):
            kv[f"cov90_{ci}_min"] = float(g.min()); kv[f"cov90_{ci}_max"] = float(g.max())
            kv[f"cov90_{ci}_med"] = float(g.median())
        g95 = cc[(cc.ci == ci) & (cc.level == 0.95)]["coverage"].dropna()
        if len(g95):
            kv[f"cov95_{ci}_med"] = float(g95.median())
    gg = cc[(cc.level == 0.90) & (cc.target == "gamma")]
    kv["cov90_gamma_rows"] = [
        dict(beta0=float(r.beta0), n=int(r.n), ci=r.ci, cov=float(r.coverage))
        for r in gg.itertuples()]

# 5) I型截尾可行率范围
if os.path.exists("results/p2t1_summary.csv"):
    tt = pd.read_csv("results/p2t1_summary.csv")
    g = tt.groupby(["beta0", "n", "p_cens"])["feasible_rate"].first()
    kv["t1_feas_min"] = float(g.min()); kv["t1_feas_minkey"] = str(g.idxmin())
    kv["t1_feas_p05_n10"] = float(g.get((2.0, 10, 0.5), np.nan))
    kv["t1_feas_p05_n20"] = float(g.get((2.0, 20, 0.5), np.nan))

with open("results/report_data.json", "w", encoding="utf-8") as f:
    json.dump(RD, f, ensure_ascii=False, indent=1, default=float)
print("AUGMENT DONE")
